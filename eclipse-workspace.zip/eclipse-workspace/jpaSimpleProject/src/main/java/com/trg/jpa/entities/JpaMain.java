package com.trg.jpa.entities;

import java.sql.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaMain {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA1");
		EntityManager em=emf.createEntityManager();
		
		
		Student s1=new Student(10,"Komal",56);
		Student s2=new Student(20,"Kumar",76);
		Student s3=new Student(30,"Akk",70.05f);
		Student s4=new Student(40,"Dkk",85);
		Student s5=new Student(50,"ppkk",45.50f);
		Student s6=new Student(60,"gkk",95);
		Student s7=new Student(70,"skk",75);

		
		
		em.getTransaction().begin();
		em.persist(s1);
		em.persist(s2);
		em.persist(s3);
		em.persist(s4);
		em.persist(s5);
		em.persist(s6);
		em.persist(s7);

		em.getTransaction().commit();

		
		System.out.println("Two object saved to database");
		em.close();
		emf.close();
		
	}

}
