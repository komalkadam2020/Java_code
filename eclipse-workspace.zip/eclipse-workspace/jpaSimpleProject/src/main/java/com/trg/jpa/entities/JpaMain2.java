package com.trg.jpa.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaMain2 {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA1");
		EntityManager em=emf.createEntityManager();
		
		Student std=em.find(Student.class, 30);
		if(std!=null) 
		{
		System.out.println(std);
		std.setMarks(55);
		em.merge(std);
		}
		else
			System.out.println("Student not found");
		
		Student std1=em.find(Student.class,40);
		if(std!=null) 
		{
		em.remove(std1);
		em.getTransaction().commit();
		System.out.println("remove");
		}
		else
			System.out.println("Student not found");

		//System.out.println("Two object saved to database");
		em.close();
		emf.close();
		
		
	}

}
