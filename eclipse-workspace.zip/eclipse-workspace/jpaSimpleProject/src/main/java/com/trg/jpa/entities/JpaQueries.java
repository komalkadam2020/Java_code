package com.trg.jpa.entities;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JpaQueries {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA1");
		EntityManager em=emf.createEntityManager();
		
		
		Query q=em.createQuery("from Student s where s.marks > 60");
		List<Student> list=q.getResultList();
		
		for(Student s:list) {
			System.out.println(s);
		}
		
		q=em.createQuery("from Student s where s.studentId=30");
		
		System.out.println("====================================");
		
		Student s=(Student)q.getSingleResult();
		
		System.out.println(s);
		
		
		em.close();
		emf.close();
		

	}

}
