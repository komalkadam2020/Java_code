package com.trg.jpa.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JpaNamedQueries {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA1");
		EntityManager em=emf.createEntityManager();
		
		
		Query q=em.createNamedQuery("findAllStudents");
		List<Student> list=q.getResultList();
		
		System.out.println("==========List of Students==========");
		for(Student s:list) {
			System.out.println(s);
		}
		
		
		
		q=em.createNamedQuery("findFailedStudents");
		q.setParameter("passmarks", 50.0f);
		 
		List<Student> passlist=q.getResultList();
		
		System.out.println("==========List of Failed Students==========");
		for(Student s:passlist) {
			System.out.println(s);
		}
		
		
		
		 q=em.createNamedQuery("findTopStudents");
			q.setParameter("topmarks", 90.0f);
			 
			List<Student> toplist=q.getResultList();
			
			System.out.println("==========List of Top Students==========");
			for(Student s:toplist) {
				System.out.println(s);
			}
		
	}

}
