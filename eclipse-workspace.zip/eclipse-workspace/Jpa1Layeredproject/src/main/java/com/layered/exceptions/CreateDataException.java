package com.layered.exceptions;

public class CreateDataException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CreateDataException(String msg) {
		super(msg);
	}	
}
