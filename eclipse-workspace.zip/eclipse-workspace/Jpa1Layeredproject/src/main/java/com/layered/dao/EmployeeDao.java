package com.layered.dao;

import java.util.List;

import com.layered.entity.Employee;
import com.layered.exceptions.*;

public interface EmployeeDao 
{
	Employee getEmployee(int empid);		//Return null of object not found
	List<Employee> getAllEmployee();
	
	void saveEmployee(Employee e) throws CreateDataException;
	void updateEmployee(Employee e) throws InvalidUpdateRequestException;
	
	void deleteEmployee(int empid) throws DataNotFoundException;
}
