package com.layered.exceptions;

public class InvalidUpdateRequestException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidUpdateRequestException(String msg)
	{
		super(msg);
	}
}
