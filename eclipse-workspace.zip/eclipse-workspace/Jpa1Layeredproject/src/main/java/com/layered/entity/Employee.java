package com.layered.entity;

import javax.persistence.Column;
import javax.persistence.Id;

public class Employee implements Comparable<Employee> {
	
	@Id
	private int eid;
	@Column(length =15)
	private String name;
	private float salary;
	
	
	public Employee() {
		super();
	}
	
	
	public Employee(int eid, String name, float salary) {
		super();
		this.eid = eid;
		this.name = name;
		this.salary = salary;
	}
	public int getEid() {
		return eid;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "\nid=" + eid + "\nname=" + name + "\nsalary=" + salary;
	}
	public int compareTo(Employee e) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	

}
