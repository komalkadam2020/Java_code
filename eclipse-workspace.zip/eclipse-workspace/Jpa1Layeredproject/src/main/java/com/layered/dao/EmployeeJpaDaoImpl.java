package com.layered.dao;

import java.util.List;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.layered.entity.Employee;
import com.layered.exceptions.*;

public class EmployeeJpaDaoImpl implements EmployeeDao{
	
	EntityManager em;
	EntityManagerFactory emf;
	
	public EmployeeJpaDaoImpl() {
		
		emf=Persistence.createEntityManagerFactory("JPA1");
		em=emf.createEntityManager();
		
		
	}

	@Override
	public Employee getEmployee(int empid) {
		
	Employee e=em.find(Employee.class, empid);
	return e;
		
	}

	@Override
	public List<Employee> getAllEmployee() {

		Query q=em.createQuery("from Employee");
		List<Employee> list=q.getResultList();
		
		return list;
	}

	@Override
	public void saveEmployee(Employee e) throws CreateDataException {
		try {
		em.getTransaction().begin();
		em.persist(e);
		em.getTransaction().commit();
		
		} catch (EntityExistsException e1) {
			
			throw new CreateDataException("Employee data with id "+e.getEid()+" already exist");
		}
		
		
		
	}

	@Override
	public void updateEmployee(Employee e) throws InvalidUpdateRequestException {
		
		Employee x=em.find(Employee.class, e.getEid());
		if(x==null)
			throw new InvalidUpdateRequestException("Employee data with id "+e.getEid()+" to update not found");
		
		x.setName(e.getName());
		x.setSalary(e.getSalary());
		
		em.getTransaction().begin();
		em.remove(x);
		em.getTransaction().commit();
		
	}

	@Override
	public void deleteEmployee(int empid) throws DataNotFoundException {

		Employee x=em.find(Employee.class, empid);
		if(x==null)
			throw new DataNotFoundException("Employee data with id "+empid+" to delete not found");
		
		em.getTransaction().begin();
		em.remove(x);
		em.getTransaction().commit();
			
	}
	
	@Override
	public void finalize() {
		emf.close();
	}
	

}
