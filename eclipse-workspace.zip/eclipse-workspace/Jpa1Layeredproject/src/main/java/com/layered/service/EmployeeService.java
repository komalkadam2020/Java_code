package com.layered.service;

import java.util.List;
import com.layered.Employee;
import com.layered.exceptions.ServiceException;

public interface EmployeeService 
{
	Employee getEmployee(int empid);
	void createEmployee(Employee e);
	List<Employee> getAllEmployees();
	void raiseSalary(int empid, float percent) throws ServiceException;
	float getTotalSalary();
	void deleteEmployee(int empid) throws ServiceException;
	List<Employee> getAllWithSalaryRange(float min, float max);
	
}
