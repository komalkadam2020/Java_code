package com.layered.main;

//import com.layered.dao.EmployeeDAOMapImpl;
import com.layered.service.EmployeeServiceMapImpl;

public class SimpleMain 
{

	public static void main(String[] args) 
	{
		//EmployeeDAOMapImpl emp = new EmployeeDAOMapImpl();
		
		EmployeeServiceMapImpl emp = new EmployeeServiceMapImpl();
		
		//System.out.println(emp.getAllEmployees());
		System.out.println(emp.getEmployee(102));
		System.out.println(emp.getAllWithSalaryRange(25000, 30000));
		System.out.println("Total Salary of Employees :" + emp.getTotalSalary());
		
	}
}
