package com.sasken.entity;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main3 {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA1");
		EntityManager em=emf.createEntityManager();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter account number");
		int accountNo=sc.nextInt();
		System.out.println("type of operation");
		//sc.next();
		
		
		String operation=sc.next();
		
		System.out.println("enter ammount");
		int ammount=sc.nextInt();
		
		BankAccount account=em.find(BankAccount.class, accountNo);
		if(account==null) {
			System.out.println("Account does not exist");
		}
		else {
			em.getTransaction().begin();
			if(operation.equals("C")) {
				account.setBalance(account.getBalance()+ammount);
				System.out.println("Ammount credited");
			}
			else {
				account.setBalance(account.getBalance()-ammount);
			
				System.out.println("Ammount debited");
			}
			System.out.println(account.getBalance());
			em.getTransaction().commit();
			
		}
		
	}

}
