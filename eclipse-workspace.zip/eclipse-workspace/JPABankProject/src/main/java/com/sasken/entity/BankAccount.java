package com.sasken.entity;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="bank_tbl")
public class BankAccount {
	
	@Id
	//@Column(name= "ACCOUNT_NO", columnDefinition="number(10)")
	private int accountNo;
	
	@Column(length = 20)
	private String name;
	
	@Column(length = 20)
	private String address;
	
	@Column(length = 20)
	private float balance;
	
	@Column(length = 20)
	private Date openingDate;
	
	
	
	public BankAccount() {
		super();
	}


	public BankAccount(int accountNo, String name, String address, float balance, Date openingDate) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.address = address;
		this.balance = balance;
		this.openingDate = openingDate;
	}


	public int getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public float getBalance() {
		return balance;
	}


	public void setBalance(float balance) {
		this.balance = balance;
	}


	public Date getOpeningDate() {
		return openingDate;
	}


	public void setOpeningDate(Date date) {
		this.openingDate = date;
	}


	@Override
	public String toString() {
		return "Bank Account No=" + accountNo + ", name=" + name + ", address=" + address + ", balance="
				+ balance + ", openingDate=" + openingDate + "]";
	}


	public void getBalance(float f) {
		// TODO Auto-generated method stub
		
	}
	
	

}
