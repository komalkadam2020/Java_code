package com.sasken.entity;

import java.sql.Date;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main1 {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA1");
		EntityManager em=emf.createEntityManager();
		
		
		
		BankAccount b1=new BankAccount(100,"Komal","Pune",50000, Date.valueOf("2018-06-01"));
		BankAccount b2=new BankAccount(200,"Akash","Shirdi",15000,Date.valueOf("2021-01-01"));
		BankAccount b3=new BankAccount(300,"Mahesh","Mumbai",40000,Date.valueOf("2021-01-01"));
		BankAccount b4=new BankAccount(400,"Kunal","Nashik",75000,Date.valueOf("2021-01-01"));
		BankAccount b5=new BankAccount(500,"Ankita","Nagpur",65000,Date.valueOf("2021-01-01"));
		
		em.getTransaction().begin();
		em.persist(b1);
		em.persist(b2);
		em.persist(b3);
		em.persist(b4);
		em.persist(b5);

		em.getTransaction().commit();
		

		System.out.println("Object saved to database");
		em.close();
		emf.close();
		

		
		
	}

}
