package com.layered.main;

import java.util.List;
import java.util.Scanner;

import com.layered.Employee;
import com.layered.exceptions.ServiceException;
import com.layered.service.EmployeeServiceMapImpl;

public class Main 
{
	@SuppressWarnings("resource")
	public static void main(String[] args) 
	{
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		EmployeeServiceMapImpl emp = new EmployeeServiceMapImpl();
		while(true)
		{
			System.out.println("\n----------------------------------");
			System.out.println("1. Create Employee\n2. Get Employee\n3. Get All Employees\n"
					+ "4. Delete Employees\n5. Raise Salary\n6. Get All with Salary Range\n"
					+ "7. Get Total Salary\n8. Exit\n");
			
			System.out.print("Enter Your Choice: ");
			choice = sc.nextInt();
			System.out.println("----------------------------------");
			int id = 0;
			String name;
			float salary;
			
			
			switch(choice)
			{
				case 1:
					System.out.println("Enter Employee Details:");
					System.out.print("Enter Id: ");
					id = sc.nextInt();
					System.out.print("Enter Name: ");
					sc.nextLine();
					name = sc.nextLine();
					System.out.print("Enter Salary: ");
					salary = sc.nextFloat();
					emp.createEmployee(new Employee(id, name, salary));
					break;
					
				case 2:
					System.out.println("Enter Employee ID to get Details: ");
					id = sc.nextInt();
					System.out.print("Employee Details: " + emp.getEmployee(id));
					break;
					
				case 3:
					System.out.println("All Employee Details:");
					System.out.println(emp.getAllEmployees());
					break;
					
				case 4:
					System.out.print("Enter Employee ID you want to delete: ");
					id = sc.nextInt();
					emp.deleteEmployee(id);
					break;
					
				case 5:
					System.out.print("Enter Employee ID whose salary you want to raise: ");
					id = sc.nextInt();
					System.out.println("Enter how much salary you want to raise (in %): ");
					float per = sc.nextFloat();
					try {
						emp.raiseSalary(id, per);
					} catch (ServiceException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					break;
					
				case 6:
					System.out.print("Enter Min range of salary: ");
					float min = sc.nextFloat();
					System.out.print("Enter Min range of salary: ");
					float max = sc.nextFloat();
					
					List<Employee> empl = emp.getAllWithSalaryRange(min, max);
					
					for(Employee e: empl)
						System.out.println(e);
					break;
					
				case 7:
					System.out.print("Total Salary of Employees: " + emp.getTotalSalary());
					break;
					
				case 8:
					return;
				default:
					System.out.println("Invalid Choice!");
			}
		}
	}
}
