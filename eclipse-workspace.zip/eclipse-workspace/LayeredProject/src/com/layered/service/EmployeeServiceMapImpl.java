package com.layered.service;

import java.util.*;
import com.layered.Employee;
import com.layered.dao.EmpDAO;
import com.layered.dao.EmployeeDAOJdbcImpl;
import com.layered.exceptions.*;

public class EmployeeServiceMapImpl implements EmployeeService
{	
	EmpDAO empl = new EmployeeDAOJdbcImpl();
	
	@Override
	public Employee getEmployee(int empid) 
	{
		return empl.getEmployee(empid);
	}

	@Override
	public List<Employee> getAllEmployees() 
	{
		return empl.getAllEmployees();
	}

	@Override
	public void raiseSalary(int empid, float percent) throws ServiceException 
	{
		Employee em = empl.getEmployee(empid);
		if(em == null)
			throw new ServiceException("Employee with id "+ empid +" Not Found!");
		
		float sal = em.getSalary() + (em.getSalary() * (percent/100));
		em.setSalary(sal);
		
		try {
			empl.updateEmployee(em);
			System.out.println("Salary of the Employee "+ em.getName() + " is Raised!");
		}
		catch (InvalidUpdateRequestException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public float getTotalSalary() 
	{
		float total = 0;
		List<Employee> list = empl.getAllEmployees();
		
		for(Employee e : list)
			total = total + e.getSalary();
		
		return total;
	}

	@Override
	public void deleteEmployee(int empid)
	{
		try {
			empl.deleteEmployee(empid);
		} catch (DataNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Override
	public List<Employee> getAllWithSalaryRange(float min, float max) 
	{
		List<Employee> list1 = empl.getAllEmployees();
		List<Employee> list2 = new ArrayList<Employee>();
		
		for(Employee e : list1)
			if(e.getSalary() >= min && e.getSalary() <= max)
				list2.add(e);
		
		return list2;
	}

	@Override
	public void createEmployee(Employee e) 
	{
		try {
			empl.saveEmployee(e);
		} catch (CreateDataException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
		}
	}
}
