package com.layered.dao;

import java.util.List;
import com.layered.Employee;
import com.layered.exceptions.*;

public interface EmpDAO 
{
	Employee getEmployee(int empid);		//Return null of object not found
	List<Employee> getAllEmployees();
	
	void saveEmployee(Employee e) throws CreateDataException;
	void updateEmployee(Employee e) throws InvalidUpdateRequestException;
	
	void deleteEmployee(int empid) throws DataNotFoundException;
}
