package com.layered.dao;

import java.io.*;
import java.sql.*;
import java.util.*;

import com.layered.Employee;
import com.layered.exceptions.*;

public class EmployeeDAOJdbcImpl implements EmpDAO {

	Connection con;

	public EmployeeDAOJdbcImpl() {
		Properties pro = new Properties();
		try {
			pro.load(new FileReader("jdbc.properties"));

			String driver = pro.getProperty("driverPath");
			String url = pro.getProperty("connectURL");
			String user = pro.getProperty("userName");
			String pass = pro.getProperty("password");

			Class.forName(driver);

			con = DriverManager.getConnection(url, user, pass);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		} catch (IOException e) {
			System.out.println("Properties File not Found!");
			System.exit(0);
		}
	}

	@Override
	public void saveEmployee(Employee e) throws CreateDataException {
		try {
			PreparedStatement pst = con.prepareStatement("insert into emp values(?, ?, ?)");
			int id = e.getId();
			String name = e.getName();
			Float sal = e.getSalary();

			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setFloat(3, sal);

			pst.executeUpdate();

		} catch (SQLException e1) {
			if (e1.getErrorCode() == 1)
				System.out.println("Employe with ID " + e.getId() + " already Exists!!");
		}
	}

	@Override
	public Employee getEmployee(int empId) {
		try {
			PreparedStatement pst = con.prepareStatement("select * from emp where eid = ?");
			pst.setInt(1, empId);

			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				float sal = rs.getFloat(3);
				Employee e = new Employee(id, name, sal);
				return e;
			} else
				return null;
		} catch (SQLException e) {
			System.out.println("Enter Valid Employee ID!!");

		}

		return null;
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> list = null;
		try {
			Statement st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from emp");
			int id;
			String name;
			float sal;

			list = new ArrayList<Employee>();
			while (rs.next()) {
				id = rs.getInt(1);
				name = rs.getString(2);
				sal = rs.getFloat(3);
				Employee e = new Employee(id, name, sal);
				list.add(e);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public void updateEmployee(Employee e) throws InvalidUpdateRequestException {
		try {
			PreparedStatement pst = con.prepareStatement("update emp set eid=?, salary=? where eid=?");
			pst.setString(1, e.getName());
			pst.setFloat(2, e.getSalary());
			pst.setInt(3, e.getId());

			int count = pst.executeUpdate();
			if (count == 0)
				throw new InvalidUpdateRequestException("Employee Data Not Found!");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

	}

	@Override
	public void deleteEmployee(int empid) throws DataNotFoundException {
		try {
			PreparedStatement pst = con.prepareStatement("delete from emp where eid=?");

			pst.setInt(1, empid);

			int count = pst.executeUpdate();
			if (count == 0)
				throw new DataNotFoundException("Data you want to delete not found!");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

	}

}
