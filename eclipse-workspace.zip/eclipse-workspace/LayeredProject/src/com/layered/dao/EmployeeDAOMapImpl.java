package com.layered.dao;

import java.io.*;
import java.util.*;
import com.layered.Employee;
import com.layered.exceptions.*;

public class EmployeeDAOMapImpl implements EmpDAO
{
	HashMap<Integer, Employee> data = new HashMap<Integer, Employee>();
	
	public EmployeeDAOMapImpl()
	{
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader("D:/Employee.txt"));
			
			while(true)
			{
				String text = br.readLine();
				
				if(text == null)
					break;
				
				String fields[] = text.split(",");
				
				if(fields.length != 3)
				{
					System.out.println("Invalid Data Format -> " + text);
					continue;
				}
				
				try {
				int eid = Integer.parseInt(fields[0]);
				float sal = Float.parseFloat(fields[2]);
				Employee e = new Employee(eid, fields[1], sal);
				
				if(data.containsKey(eid))
					System.out.println("Employee with ID " + eid + " already exists!");
				data.put(eid, e);
				} catch(NumberFormatException nfe)
				{
					System.out.println("Invalid Numeric Data -> " + text);
					
				}
			}
			br.close();
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Employee getEmployee(int empid) 
	{
		Employee e = data.get(empid);
		return e;
	}

	@Override
	public List<Employee> getAllEmployees() 
	{
		Collection<Employee> col = data.values();
		List<Employee> list = new ArrayList<Employee>();
		list.addAll(col);
		//Collections.sort(list);
		return list;
	}

	@Override
	public void saveEmployee(Employee e) throws CreateDataException 
	{
		if(data.containsKey(e.getId()))
			throw new CreateDataException("Employee already exists!");
		
		data.put(e.getId(), e);
		System.out.println("Record Added!");
	}

	@Override
	public void updateEmployee(Employee e) throws InvalidUpdateRequestException 
	{
		if(data.containsKey(e.getId()))
		{
			data.replace(e.getId(), e);
			System.out.println("Record Updated!");
		}
		else
			throw new InvalidUpdateRequestException("Employee Data Not Found!");
	}

	@Override
	public void deleteEmployee(int empid) throws DataNotFoundException 
	{
		if(data.containsKey(empid))
		{
			data.remove(empid);
			System.out.println("Record Removed!");
		}
			
		else
			throw new DataNotFoundException("Data you want to delete not found!");
	}
}
