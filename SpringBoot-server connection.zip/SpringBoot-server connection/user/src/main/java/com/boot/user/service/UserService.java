package com.boot.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.user.Entity.User;
import com.boot.user.repo.UserRepository;


@Service
public class UserService {
	
	@Autowired
	UserRepository repository;
	
	public List<User> getAllUser(){
		List<User> list=repository.findAll();
		return list;
	}

}
