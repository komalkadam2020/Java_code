package com.trg.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootemployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootemployeeApplication.class, args);
	}

}
