package com.sasken.EmployeeManager.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.sasken.EmployeeManager.Entity.AppResponse;
import com.sasken.EmployeeManager.exception.EmployeeDuplicateException;
import com.sasken.EmployeeManager.exception.EmployeeNotFoundException;


@ControllerAdvice
public class ErrorHandler {

	@ExceptionHandler(EmployeeDuplicateException.class)
	public ResponseEntity<AppResponse> handleMD(EmployeeDuplicateException exp) {

		return new ResponseEntity<AppResponse>(new AppResponse(exp.getCode(), exp.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<AppResponse> handleMNF(EmployeeNotFoundException exp) {
		return new ResponseEntity<AppResponse>(new AppResponse(exp.getCode(), exp.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

}