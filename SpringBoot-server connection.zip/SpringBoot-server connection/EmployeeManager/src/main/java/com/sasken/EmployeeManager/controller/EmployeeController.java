package com.sasken.EmployeeManager.controller;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sasken.EmployeeManager.Entity.AppResponse;
import com.sasken.EmployeeManager.Entity.Employee;
import com.sasken.EmployeeManager.exception.EmployeeNotFoundException;
import com.sasken.EmployeeManager.service.EmployeeService;

@RestController
@RequestMapping("/employee")
@CrossOrigin(origins="http://localhost:4200")
public class EmployeeController {
	
	private final EmployeeService service;

	public EmployeeController(EmployeeService service) {
		this.service = service;
	}
	
	 @GetMapping("/all")
	public List<Employee> getAllEmployees() {
		return service.findAllEmployees();
	}
	
	 @GetMapping("/{id}")
		public Employee getEmployee(@PathVariable("id") Long id) {
			return service.findEmployeeById(id);
		}
	 
	 @PostMapping("/add")
		public ResponseEntity<AppResponse> addEmployee(@RequestBody Employee employee) {
			service.addEmployee(employee);
			return new ResponseEntity<AppResponse>(
					new AppResponse("success", "Employee with id " + employee.getId() + " successfully saved"), HttpStatus.CREATED);
		} 
	 
	 @PutMapping("/update")
		public ResponseEntity<AppResponse> updateEmployee(@RequestBody Employee e) {
			service.updateEmployee(e);
			return new ResponseEntity<AppResponse>(
					new AppResponse("success", "Employee with id " + e.getId() + " successfully updated"),
					HttpStatus.OK);
		}

	 
		@DeleteMapping("/delete/{id}")
		public ResponseEntity<AppResponse> deleteEmployee(@PathVariable("id") Long id) {
			service.deleteEmployee(id);
			return new ResponseEntity<AppResponse>(
					new AppResponse("success", "Employee with id " + id + " successfully deleted"), HttpStatus.OK);
		}
		
	 
	
	
	
}
