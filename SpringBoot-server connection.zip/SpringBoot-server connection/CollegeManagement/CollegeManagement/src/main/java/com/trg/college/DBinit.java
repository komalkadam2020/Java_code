package com.trg.college;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.stereotype.Service;


import com.trg.college.entity.Student;
import com.trg.college.entity.Teacher;
import com.trg.college.repo.StudentRepository;
import com.trg.college.repo.TeacherRepository;

@Service
public class DBinit implements CommandLineRunner {
	@Autowired
	StudentRepository stdrepository;
	
	@Autowired
	TeacherRepository tearepository;
	

	Logger logger = LoggerFactory.getLogger(DBinit.class);

	@Override
	public void run(String... args) throws Exception {

		stdrepository.save(new Student(100, "Shilpa Waghmare", 15000, "F","IT","shilpawaghmare@gmail.com",null));
		stdrepository.save(new Student(200, "Komal Kadam", 17000, "F","ENTC","komalkadam@gmail.com",null));
		stdrepository.save(new Student(300, "Vaishnavi Kokate", 18000, "F","ENTC","vaishnavikokate@gmail.com",null));
		stdrepository.save(new Student(400, "Sanchita Chavan", 20000, "F","MECH","sanchitachavan@gmail.com",null));
		stdrepository.save(new Student(500, "Akshay Shinde", 15000, "M","Civil","akshayshinde@gmail.com",null));
		stdrepository.save(new Student(600, "Akash Kumar", 25000, "M","MECH","akashkumar@gmail.com",null));
		stdrepository.save(new Student(700, "Suresh kumar", 23000, "M","Computer","sureshkuma@gmailr.com",null));
		
		logger.info("Initial Student objects added to the table");
		
		
		tearepository.save(new Teacher(10, "Bhavesh Patil","Java","sureshkumar@gmail.com"));
		tearepository.save(new Teacher(20, "Sanket kumar","SQL","saketkumar@gmail.com"));
		tearepository.save(new Teacher(30, "kalpesh Patil","Python","kalpeshkumar@gmail.com"));
		tearepository.save(new Teacher(40, "rohini Patil","Advance Java","rohinipatil@gmail.com"));
		tearepository.save(new Teacher(50, "shubham kale","CPP","shubhamkale@gmail.com"));
		tearepository.save(new Teacher(60, "aditi Patil","core","aditipatil@gmail.com"));
		tearepository.save(new Teacher(70, "suresh Patil","full stack","sureshpatilr@gmail.com"));
		
		logger.info("Initial Teacher objects added to the table");
		
	}

}
