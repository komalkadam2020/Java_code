package com.trg.college.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trg.college.entity.Student;
import com.trg.college.entity.Teacher;

public interface TeacherRepository  extends JpaRepository<Teacher,Integer>{

}
