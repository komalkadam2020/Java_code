package com.trg.college.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.trg.college.entity.Student;
import com.trg.college.exceptions.StudentDuplicateException;
import com.trg.college.exceptions.StudentNotFoundException;
import com.trg.college.repo.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	StudentRepository repository;

	public List<Student> getAllStudent() {

		List<Student> list = repository.findAll();
		return list;
	}

	public Student getStudent(int studentId) {
		Optional<Student> opt = repository.findById(studentId);
		if (!opt.isPresent())
			throw new StudentNotFoundException("NOT_FND", "Student data with id " + studentId + " not found");
		return opt.get();
	}

	public void saveStudent(Student m) {
		if (repository.existsById(m.getStudentId()))
			throw new StudentDuplicateException("SAVE_FAIL", "Student wiith id " + m.getStudentId() + " already exists");
		repository.save(m);
	}

	public void updateStudent(Student e) {
		if (repository.existsById(e.getStudentId()))
			repository.save(e);
		else
			throw new StudentNotFoundException("UPDT_FAIL",
					"Student wiith id " + e.getStudentId() + " to update not found");

	}

	public void deleteStudent(int mid) {
		if (repository.existsById(mid)) {
			repository.deleteById(mid);
		} else {
			throw new StudentNotFoundException("NOT_FND", "Student data with id " + mid + " to delete not found");
		}

	}
}
