package com.trg.college.exceptions;

public class StudentNotFoundException  extends RuntimeException{

	private String code;
	private String message;
	
	public StudentNotFoundException(String code, String message) {
		super();
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}
	

}
