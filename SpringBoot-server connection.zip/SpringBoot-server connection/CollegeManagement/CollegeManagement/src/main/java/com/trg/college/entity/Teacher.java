package com.trg.college.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Teacher {
    @Id
	private int teacherId;
    @Column(length=25)
	private String teacherName;
    @Column(length=25)
	private String specification;
    @Column(length=25)
	private String teacherEmail;
	
    
    public Teacher() {
		super();
	}


	public Teacher(int teacherId, String teacherName, String specification, String teacherEmail) {
		super();
		this.teacherId = teacherId;
		this.teacherName = teacherName;
		this.specification = specification;
		this.teacherEmail = teacherEmail;
	}


	public int getTeacherId() {
		return teacherId;
	}


	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}


	public String getTeacherName() {
		return teacherName;
	}


	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}


	public String getSpecification() {
		return specification;
	}


	public void setSpecification(String specification) {
		this.specification = specification;
	}


	public String getTeacherEmail() {
		return teacherEmail;
	}


	public void setTeacherEmail(String teacherEmail) {
		this.teacherEmail = teacherEmail;
	}


	@Override
	public String toString() {
		return "Teacher [teacherId=" + teacherId + ", teacherName=" + teacherName + ", specification=" + specification
				+ ", teacherEmail=" + teacherEmail + "]";
	}
	
	
	
	
}
