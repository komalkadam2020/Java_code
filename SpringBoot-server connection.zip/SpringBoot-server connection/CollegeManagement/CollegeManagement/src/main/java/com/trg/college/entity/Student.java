package com.trg.college.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Student {
	@Id
	private int studentId;
	@Column(length=25)
	private String studentName;
	@Column(length=25)
	private float studentFee;
	@Column(length=25)
	private String studentGender;
	@Column(length=25)
	private String studentBranch;
	@Column(length=25)
	private String studentEmail;
	@OneToOne
	@JoinColumn(name="teacherId")
	private Teacher teacher;

	public Student() {
		super();
	}

	public Student(int studentId, String studentName, float studentFee, String studentGender, String studentBranch,
			String studentEmail, Teacher teacher) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentFee = studentFee;
		this.studentGender = studentGender;
		this.studentBranch = studentBranch;
		this.studentEmail = studentEmail;
		this.teacher = teacher;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public float getStudentFee() {
		return studentFee;
	}

	public void setStudentFee(float studentFee) {
		this.studentFee = studentFee;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public String getStudentBranch() {
		return studentBranch;
	}

	public void setStudentBranch(String studentBranch) {
		this.studentBranch = studentBranch;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentFee=" + studentFee
				+ ", studentGender=" + studentGender + ", studentBranch=" + studentBranch + ", studentEmail="
				+ studentEmail + ", teacher=" + teacher + "]";
	}
	
	
	
	
	
	
}

	