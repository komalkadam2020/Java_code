package com.trg.college.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.trg.college.entity.Student;
import com.trg.college.entity.Teacher;
import com.trg.college.exceptions.StudentDuplicateException;
import com.trg.college.exceptions.StudentNotFoundException;
import com.trg.college.exceptions.TeacherDuplicateException;
import com.trg.college.exceptions.TeacherNotFoundException;
import com.trg.college.repo.StudentRepository;
import com.trg.college.repo.TeacherRepository;

@Service
public class TeacherService {
	
	@Autowired
	TeacherRepository repository;

	public List<Teacher> getAllTeacher() {

		List<Teacher> list = repository.findAll();
		return list;
	}

	public Teacher getTeacher(int TeacherId) {
		Optional<Teacher> opt = repository.findById(TeacherId);
		if (!opt.isPresent())
			throw new TeacherNotFoundException("NOT_FND", "Teacher data with id " + TeacherId + " not found");
		return opt.get();
	}

	public void saveTeacher(Teacher m) {
		if (repository.existsById(m.getTeacherId()))
			throw new TeacherDuplicateException("SAVE_FAIL", "Teacher wiith id " + m.getTeacherId() + " already exists");
		repository.save(m);
	}

	public void updateTeacher(Teacher e) {
		if (repository.existsById(e.getTeacherId()))
			repository.save(e);
		else
			throw new TeacherNotFoundException("UPDT_FAIL",
					"Teacher wiith id " + e.getTeacherId() + " to update not found");

	}

	public void deleteTeacher(int mid) {
		if (repository.existsById(mid)) {
			repository.deleteById(mid);
		} else {
			throw new TeacherNotFoundException("NOT_FND", "Teacher data with id " + mid + " to delete not found");
		}

	}
}
