package com.trg.college.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trg.college.entity.AppResponse;
import com.trg.college.entity.Student;
import com.trg.college.service.StudentService;

@RestController
@RequestMapping("students")
@CrossOrigin(origins="http://localhost:4200" )
public class StudentController {

	@Autowired
	StudentService service;

	@PostMapping()
	public ResponseEntity<AppResponse> saveStudent(@RequestBody Student e) {

		service.saveStudent(e);

		return new ResponseEntity<AppResponse>(
				new AppResponse("success", "Student with id " + e.getStudentId() + " successfully saved"), HttpStatus.OK);
	}

	@PutMapping()
	public ResponseEntity<AppResponse> updateStudent(@RequestBody Student e) {

		service.updateStudent(e);

		return new ResponseEntity<AppResponse>(
				new AppResponse("success", "Student with id " + e.getStudentId() + " successfully updated"),
				HttpStatus.OK);
	}

	@DeleteMapping("{studentId}")
	public ResponseEntity<AppResponse> deleteStudent(@PathVariable("studentId") int eid) {

		service.deleteStudent(eid);
		return new ResponseEntity<AppResponse>(
				new AppResponse("success", "Student with id " + eid + " successfully deleted"), HttpStatus.OK);
	}

	@GetMapping
	public List<Student> getAllStudent() {
		return service.getAllStudent();
	}

	@GetMapping("{studentId}")
	public Student getStudent(@PathVariable int studentId) {

		return service.getStudent(studentId);
	}

}
