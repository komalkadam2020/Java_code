package com.trg.college.handlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.trg.college.entity.AppResponse;
import com.trg.college.exceptions.StudentDuplicateException;
import com.trg.college.exceptions.StudentNotFoundException;
import com.trg.college.exceptions.TeacherDuplicateException;
import com.trg.college.exceptions.TeacherNotFoundException;

@ControllerAdvice
public class ErrorHandler {

	@ExceptionHandler(StudentDuplicateException.class)
	public ResponseEntity<AppResponse> handleMD(StudentDuplicateException exp) {

		return new ResponseEntity<AppResponse>(new AppResponse(exp.getCode(), exp.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(StudentNotFoundException.class)
	public ResponseEntity<AppResponse> handleMNF(StudentNotFoundException exp) {
		return new ResponseEntity<AppResponse>(new AppResponse(exp.getCode(), exp.getMessage()),
				HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(TeacherDuplicateException.class)
	public ResponseEntity<AppResponse> handleMD(TeacherDuplicateException exp) {

		return new ResponseEntity<AppResponse>(new AppResponse(exp.getCode(), exp.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(TeacherNotFoundException.class)
	public ResponseEntity<AppResponse> handleMNF(TeacherNotFoundException exp) {
		return new ResponseEntity<AppResponse>(new AppResponse(exp.getCode(), exp.getMessage()),
				HttpStatus.BAD_REQUEST);
	}

}