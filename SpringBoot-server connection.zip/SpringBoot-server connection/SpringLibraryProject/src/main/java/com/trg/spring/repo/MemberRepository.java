package com.trg.spring.repo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.trg.spring.entity.Member;


@Repository
public interface MemberRepository extends JpaRepository<Member, Integer>{
	
	List<Member> findByIssuedBookIsNotNull();
	
	@Query("select count(*) from Member m where m.issuedBook.bookId=:bid")
	long getBookIssuedCount(@Param("bid") int bookId);
	
	@Query("select count(m.issuedBook.bookId) from Member m where m.memberId=:mid")
	int checkAnyBookIssued(@Param("mid") int memberId);
	
	@Transactional
	@Modifying
	@Query("update Member m set m.issuedBook.bookId =:bid where m.memberId =:mid")
	int issueBook(int bid, int mid);
	
}
