package com.trg.spring;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import com.trg.spring.entity.Book;
import com.trg.spring.entity.Member;
//import com.trg.boot.controllers.EmployeeController;
import com.trg.spring.repo.BookRepository;
import com.trg.spring.repo.MemberRepository;


@Service
public class DBInit implements CommandLineRunner {

	
	@Autowired
	BookRepository bookRepository;
	@Autowired
	MemberRepository memberRepository;
	
	
	
	@Override
	public void run(String... args) throws Exception {
		
		bookRepository.save(new Book(111, "Learn Java", "java", "Kiran Jha"));
		bookRepository.save(new Book(222, "Learn C++", "cpp", "Raju Rao"));
		bookRepository.save(new Book(333, "Advanced Java", "java", "Kiran Jha"));
		bookRepository.save(new Book(444, "SQL Guide", "db","Sairam Kumar"));
		bookRepository.save(new Book(555, "Spring Boot", "java", "Edward Philip"));
		bookRepository.save(new Book(666, "Learn PLSQL", "db", "Jagdish reddy"));
		bookRepository.save(new Book(777, "Advance C++", "cpp", "Charlton Heston"));
		bookRepository.save(new Book(888, "JPA Handbook", "java", "Kiran Jha"));
			
		memberRepository.save(new Member(10, "Suresh", "Hyderbad", null));
		memberRepository.save(new Member(20, "Naresh", "Hyderbad", null));
		memberRepository.save(new Member(30, "Satish", "Bangalore", null));
		memberRepository.save(new Member(40, "Mahesh", "Kolkatta", null));
		memberRepository.save(new Member(50, "Raju", "Chennai", null));
		memberRepository.save(new Member(60, "Rajesh", "Bangalore", null));
		
		System.out.println("successfully added");
		
	}
	


}
