package com.trg.spring.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.trg.spring.entity.AppResponse;
import com.trg.spring.entity.Book;
import com.trg.spring.entity.Member;
import com.trg.spring.exceptions.BookDuplicateException;
import com.trg.spring.exceptions.BookIssueException;
import com.trg.spring.exceptions.BookNotFoundException;
import com.trg.spring.exceptions.MemberNotFoundException;
import com.trg.spring.repo.BookRepository;
import com.trg.spring.repo.MemberRepository;

@RestController
@RequestMapping("books")
@CrossOrigin(origins="http://localhost:4200")
public class BookController
{
	 
	@Autowired
	BookRepository repository;
	
	@Autowired
	MemberRepository memRepository;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Book> getAllBooks()
	{
		
		List<Book> list=repository.findAll();
		return list;
	}
	
	@GetMapping("getAll/{subject}")
	public List<Book> getBooksBySubject(@PathVariable("subject")   String sub)
	{
		
		List<Book> list=repository.findBySubject(sub);
		return list;
	}
	@PostMapping()
	public ResponseEntity<?> saveBook(@RequestBody Book b) throws BookDuplicateException { 
	
		if(repository.existsById(b.getBookId()))
			throw new BookDuplicateException("SAVE_FAIL", "Book with id "+b.getBookId()+" already exists");
		repository.save(b);
		return new ResponseEntity<AppResponse>(new AppResponse("SUCCESS","Book with id "+b.getBookId()+" is successfully saved"),HttpStatus.OK);
	}
	
	@DeleteMapping("{bookId}")
	public ResponseEntity<?> deleteBook(@PathVariable("bookId")   int bid) throws BookNotFoundException {
		
		if(!repository.existsById(bid))
		{
			throw new BookNotFoundException("DEL_ERR","Book with id "+bid+" to delete not found");
		}
		if(memRepository.getBookIssuedCount(bid)!=0)
		{
			throw new BookNotFoundException("DEL_ERR","Book with id "+bid+" not deleted as it is under issue.");
		}
		repository.deleteById(bid);
		return new ResponseEntity<AppResponse>(new AppResponse("SUCCESS","Book with id "+bid+" is successfully deleted."),HttpStatus.OK);
	}
	
	@PutMapping("issue/{memberId}/{bookId}")
	public ResponseEntity<?>  issueBook(@PathVariable("memberId")int mid, @PathVariable("bookId") int bid)
	{
		java.util.Optional<Member> opt = memRepository.findById(mid);
		
		if(!opt.isPresent())
			throw new BookIssueException("ISSUE_ERR","Member Id "+mid+" is invalid");
		Member m=opt.get();
		if(m.getIssuedBook() != null)
			throw new BookIssueException("ISSUE_ERR","Member with Id "+mid+" already holding with Id "+m.getIssuedBook().getBookId());
		if(memRepository.getBookIssuedCount(bid)!=0)
			throw new BookIssueException("ISSUE_ERR","Book with Id "+bid+" already under issue to other member");
		java.util.Optional<Book> optbk = repository.findById(bid);
		if(!optbk.isPresent())
			throw new BookIssueException("ISSUE_ERR","Book Id "+bid+" is invalid");
		memRepository.issueBook(bid, mid);
		return new ResponseEntity<AppResponse>(new AppResponse("SUCCESS","Member with Id "+mid+" issued to the book with Id "+bid),HttpStatus.OK);
	}
	
	@PutMapping("return/{memberId}/{bookId}")
	public ResponseEntity<AppResponse> returnBook(@PathVariable("memberId")int mid, @PathVariable("bookId") int bid)
	{
		java.util.Optional<Member> opt = memRepository.findById(mid);
		if(!opt.isPresent())
			throw new BookIssueException("ISSUE_ERR","Member Id "+mid+" is invalid");
		java.util.Optional<Book> optbk = repository.findById(bid);
		if(!optbk.isPresent())
			throw new BookIssueException("ISSUE_ERR","Book Id "+bid+" is invalid");
		Member m=opt.get();
		if(m.getIssuedBook() == null)
			throw new BookIssueException("ISSUE_ERR","Member with Id "+mid+" having no book");
		if(m.getIssuedBook().getBookId() != bid)
			throw new BookIssueException("ISSUE_ERR","Member with Id "+mid+" not having book with id "+bid);
		m.setIssuedBook(null);
		memRepository.save(m);
		return new ResponseEntity<AppResponse>(new AppResponse("SUCCESS","Member with Id "+mid+" is returned the book with Id "+bid),HttpStatus.OK);
	}
	
	@GetMapping("getSubjects")
	public List<String> getAllSub()
	{
		List<String> list = repository.findByAllSubjects();
		return list;
	}
	
}
