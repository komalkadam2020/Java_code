package com.trg.spring.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.trg.spring.entity.Book;


@Repository
public interface BookRepository  extends JpaRepository<Book, Integer> {
	
	List<Book> findBySubject(String sub);
	
	@Query("SELECT DISTINCT b.subject FROM Book b")
	List<String> findByAllSubjects();
	
}
