package com.trg.spring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Member {
	@Id
	private int memberId;
	@Column(length=15)
	private String name;
	@Column(length=15)
	private String address;
	
	@OneToOne
	@JoinColumn(name="bookId")
	private Book issuedBook;

	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Member(int memberId, String name, String address, Book issuedBook) {
		super();
		this.memberId = memberId;
		this.name = name;
		this.address = address;
		this.issuedBook = issuedBook;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Book getIssuedBook() {
		return issuedBook;
	}

	public void setIssuedBook(Book issuedBook) {
		this.issuedBook = issuedBook;
	}

	
}
