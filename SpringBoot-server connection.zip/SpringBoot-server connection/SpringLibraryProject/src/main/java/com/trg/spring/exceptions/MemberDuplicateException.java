package com.trg.spring.exceptions;

public class MemberDuplicateException extends RuntimeException {

	private String code;
	private String message;
	
	public MemberDuplicateException(String code, String message) {
		super();
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}
}