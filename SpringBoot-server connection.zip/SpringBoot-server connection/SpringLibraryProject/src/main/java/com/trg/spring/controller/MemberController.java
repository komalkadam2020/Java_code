package com.trg.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trg.spring.entity.AppResponse;
import com.trg.spring.entity.Book;
import com.trg.spring.entity.Member;
import com.trg.spring.exceptions.MemberNotFoundException;
import com.trg.spring.exceptions.BookIssueException;
import com.trg.spring.exceptions.BookNotFoundException;
import com.trg.spring.exceptions.MemberDuplicateException;
import com.trg.spring.repo.BookRepository;
import com.trg.spring.repo.MemberRepository;

@RestController
@RequestMapping("members")
@CrossOrigin(origins="http://localhost:4200")
public class MemberController {

	@Autowired
	MemberRepository repository;
	
	@Autowired
	BookRepository bookRepository;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Member> getAllMembers(){
		
		List<Member> list=repository.findAll();
		return list;
	}
	

	
	@PostMapping()
	public ResponseEntity<AppResponse> saveMember(@RequestBody Member m) throws MemberDuplicateException {  //RequestBody helps in converting JSON data in the Employee Object
	
		if(repository.existsById(m.getMemberId()))
			throw new MemberDuplicateException("Save_fail", "Member with id "+m.getMemberId()+" already exists");
		repository.save(m);
		return new ResponseEntity<AppResponse>(new AppResponse("success", "Member with id "+m.getMemberId()+" successfully saved"),HttpStatus.OK);
		
	}
	
	@DeleteMapping("{memberId}")
	public ResponseEntity<AppResponse> deleteMember(@PathVariable("memberId") int mid) throws MemberNotFoundException {
		
		if(!repository.existsById(mid))
		{
			throw new MemberNotFoundException("Not_FND", "Member with id "+mid+" to delete not found");
		}
		if(repository.checkAnyBookIssued(mid)!=0)
		{
			throw new BookNotFoundException("DEL_ERR","Member with id "+mid+" not deleted because he took a book.");
		}
		repository.deleteById(mid);
		return new ResponseEntity<AppResponse>(new AppResponse("SUCCESS","Book with id "+mid+" is successfully deleted."),HttpStatus.OK);
	}
	
	@GetMapping("bookIssued")
	public List<Member> getBookIssuedMembers()
	{
		List<Member> list = repository.findByIssuedBookIsNotNull();
		if(list.size() == 0)
			throw new MemberNotFoundException("NOT_FIND","Members with book Issued not found.");
		return list;
	}
	
	@PutMapping("changeAddress/{memberId}/{newAddress}")
	public ResponseEntity<AppResponse> updateAddress(@PathVariable("memberId") int mid, @PathVariable("newAddress")String nadd)
	{
		Optional<Member> opt = repository.findById(mid);
		if(!opt.isPresent())
			throw new BookIssueException("ISSUE_ERR","Member Id "+mid+" is invalid");
		
		if(opt.get().getAddress() == nadd)
			throw new BookIssueException("ISSUE_ERR","Member Id "+mid+" is already having the address");
		
		Member m = opt.get();
		m.setAddress(nadd);
		repository.save(m);
		return new ResponseEntity<AppResponse>(new AppResponse("UPDATE_SUCCESS","Member with id "+mid+" is successfully changed."),HttpStatus.OK);
		
		 
	}
}
