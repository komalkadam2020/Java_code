package com.trg.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootlibrariesApplicationTests {

	@Test
	void contextLoads() {
	}

}
