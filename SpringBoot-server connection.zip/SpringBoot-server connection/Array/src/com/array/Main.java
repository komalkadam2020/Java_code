package com.array;

public class Main {

	public static void main(String[] args) {
		Parent.call();
		System.out.println("b="+Parent.b);

	}
}
