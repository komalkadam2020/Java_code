package com.array;

public class Parent {
	
	
	static int a=44;
	static int b=99;
	
	static void call() {
		System.out.println("a="+a);
	}
	
	
	
	
	
	
	

	
}


