import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  loginForm=new FormGroup({
    email:new FormControl('',[Validators.required,Validators.email]),
    password:new FormControl('',[Validators.required,Validators.minLength(5)])
  })
  data: any;
  email: any;
  pass: any;
  
  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  loginUser(){
    this.data= this.loginForm.value;
    this.email=this.data.email;
    this.pass=this.data.password;
    if(this.email=='admin@gmail.com' && this.pass=='12345')
    {
      this.router.navigate(['/admin/home']);
    }
    else{
      this.router.navigate(['/user/home']);
    
    }
  }
  get emaila(){
    return this.loginForm.get('user')
  }
}
