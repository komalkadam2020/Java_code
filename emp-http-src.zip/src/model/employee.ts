export interface Employee{

    empId:number
    name:string
    salary:number
    gender:string
    //dob:Date
}