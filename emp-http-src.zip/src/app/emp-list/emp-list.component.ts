import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/model/employee';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  employees: Employee[] = [];

  constructor(private service: EmployeeDataService) {}
  
  ngOnInit(): void {
     this.service.getAllEmployees().subscribe(

      (list) => {this.employees=list},
      (error) =>{console.log(error)}

    )
  }

 

}





