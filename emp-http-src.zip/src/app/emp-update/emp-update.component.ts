import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/model/employee';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-emp-update',
  templateUrl: './emp-update.component.html',
  styleUrls: ['./emp-update.component.css']
})
export class EmpUpdateComponent implements OnInit {


  emp: Employee = { empId: 0, name: '', salary: 0, gender: '' };
  message = ''

  constructor(
    private service: EmployeeDataService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {


    this.route.paramMap.subscribe(params => {
      let eidstr: string | null = params.get("empid");
      if (eidstr == null) {

      }
      else {
        let eid = parseInt(eidstr); //+eidstr
        this.service.getEmployee(eid).subscribe(

          (response) => { 
            this.emp = response.message 
          },
          (errorResponse) => {
            this.message = errorResponse.error.message
            setTimeout(() => {
              this.router.navigate(['/emplist'])
            }, 2000);
          }
        )
      }
    });
  }

  saveData() {

    this.service.updateEmployee(this.emp).subscribe(

      (response) => {
        this.message=response.message 
        setTimeout(() => {
          this.router.navigate(['/empdetails', this.emp.empId])
        }, 2000);
      },
      (errorResponse) => {
         this.message=errorResponse.error.message;
        setTimeout(() => {
          this.router.navigate(['/empdetails', this.emp.empId])
        }, 2000);
      }
    );

  }


}


