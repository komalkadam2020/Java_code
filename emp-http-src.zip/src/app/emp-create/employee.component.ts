import { Component, EventEmitter, OnInit, Output } from '@angular/core';

import { Employee } from 'src/model/employee';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'add-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmpCreateComponent  {

 
 constructor(private service:EmployeeDataService){}

 message:string=''
 

  saveData(data:Employee) {

    this.service.addEmployee(data).subscribe(

      (response) => {
        this.message=response.message 
        setTimeout(() => { this.message='' }, 2000);
      },
      (errorResponse) => {
         this.message=errorResponse.error.message
          setTimeout(() => { this.message=''}, 2000);
      }
    );
  }


}

