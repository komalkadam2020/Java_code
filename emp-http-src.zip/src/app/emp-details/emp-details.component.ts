import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/model/employee';

import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent implements OnInit {


  emp: Employee = { empId: 0, name: '', salary: 0, gender: '' };
  message = ''

  constructor(
    private service: EmployeeDataService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {

    this.route.paramMap.subscribe(params => {
      let eidstr: string | null = params.get("empid");
      if (eidstr == null) {

      }
      else {
        let eid = parseInt(eidstr); //+eidstr
        this.service.getEmployee(eid).subscribe(

          (response: any) => { 
            this.emp=response 
          },
          (errorResponse) => { 
           this.message= errorResponse.error.message
           setTimeout(() => {
            this.router.navigate(['/emplist'])}, 2000 );
            }
          )
      }
    });
  }

  deleteEmp() {

    this.service.deleteEmployee(this.emp.empId).subscribe(

      (response) => {
        this.message=response.message
        setTimeout(() => {
          this.router.navigate(['/emplist'])
        }, 2000);
      },
      (errorResponse) =>{
        this.message=errorResponse.error.message
        setTimeout(() => {
          this.router.navigate(['/emplist'])
        }, 2000);
      }

    )
    
  }

}
