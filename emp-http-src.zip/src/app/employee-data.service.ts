import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from 'src/model/employee';

@Injectable({
  providedIn: 'root'
})

export class EmployeeDataService {

  
  constructor(private http:HttpClient){ }

  baseUrl:string='http://localhost:9090/employees';


  //to get all employees
  getAllEmployees():Observable<any>{
    return this.http.get(this.baseUrl);
  }

  //to get one employee
  getEmployee(eid:number):Observable<any>{
    return this.http.get(`${this.baseUrl}/${eid}`);
  }

  deleteEmployee(eid:number):Observable<any>{
    return this.http.delete(`${this.baseUrl}/${eid}`);
  }

  updateEmployee(emp:Employee):Observable<any>{
     return this.http.put(this.baseUrl,emp);
  }

  addEmployee(emp:Employee):Observable<any> {
    return this.http.post(this.baseUrl,emp);
  }

}



