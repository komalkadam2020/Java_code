import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Teacher } from 'src/model/teacher';
import { CollegeDataService } from '../college-data.service';

@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrls: ['./teacher-list.component.css']
})
export class TeacherListComponent implements OnInit {

  constructor(private service:CollegeDataService,private route: ActivatedRoute,
    private router: Router) { }  
  
    
  deleteMessage=false;
   
  message:string=''

  teachers:Teacher[]=[];
  
  teacher:Teacher={teacherId:0, teacherName:'', specification:'', teacherEmail:''};

 
  
  ngOnInit() {  
        
    this.service.getAllTeacher().subscribe(data =>{ 
    this.teachers =data;  
      
    })  
  }  
    
  deleteTeacher(id: number) {  
    this.service.deleteTeacher(id)  
      .subscribe(  
        data => {  
          console.log(data);
          setTimeout(() => { this.message='' }, 2000); 
         this.deleteMessage=true;  
          this.service.getAllTeacher().subscribe(data =>{  
            this.teachers =data  
           
            })  
        },  
        error => console.log(error));  
  }  

 
   
}
