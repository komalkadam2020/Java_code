import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { Student } from 'src/model/student';
import { CollegeDataService } from '../college-data.service';

@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent implements OnInit {
  
  submitted = false; 
  message:string=''

  
  constructor(private service:CollegeDataService){}
  ngOnInit() {  
    this.submitted=false;  
  }  
  
  studentsaveform=new FormGroup({  
    student_name:new FormControl('' , [Validators.required , Validators.minLength(5) ] ),  
    student_email:new FormControl('',[Validators.required,Validators.email]),  
    student_branch:new FormControl()  
  });  


  
 
   saveData(data:Student) {
 
     this.service.addStudent(data).subscribe(
 
       (response) => {
         this.message=response.message 
         setTimeout(() => { this.message='' }, 2000);
       },
       (errorResponse) => {
          this.message=errorResponse.error.message
           setTimeout(() => { this.message=''}, 2000);
       }
     );
   }

   addStudentForm(){  
    this.submitted=false;  
    this.studentsaveform.reset();  
  }  
 
}  
