export interface IUser{
    id : number;
    email : string;
    password : string;
    user : string;

}