export interface IProperty{
    property_Id : number;
    property_Type : string;
    price : number;
    status : boolean;
    contact : string;
    description : string;
    seller : any;
    latitude : number;
    longitude : number;
    place : string;
    
    
}