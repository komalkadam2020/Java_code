export interface ISeller{
    customerId : number;
    sellerId : number;
    fName : string;
    lName :string;
    phoneNumber : string;
    email : string;
    pan : string;
    adhar : string;
    password : string;

}