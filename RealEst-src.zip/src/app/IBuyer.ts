export interface IBuyer{
    customerId : number;
    buyerId : number;
    fName : string;
    lName :string;
    phoneNumber : string;
    email : string;
    pan : string;
    adhar : string;
    password : string;
    address : string;
    country : string;
    zipcode : string

}