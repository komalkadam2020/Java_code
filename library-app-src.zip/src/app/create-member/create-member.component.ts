import { Component, OnInit } from '@angular/core';
import { Member } from 'src/model/member';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-create-member',
  templateUrl: './create-member.component.html',
  styleUrls: ['./create-member.component.css']
})
export class CreateMemberComponent implements OnInit {

  constructor(private service:LibraryDataService) { }

  ngOnInit(): void {
  }

  message:string=''
  

  showData(data:Member):void {

    console.table(data)
    this.message=this.service.addMember(data);

    setTimeout(() => {this.message=''},2000 )
   
  }

}
