import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookListComponent } from './book-list/book-list.component';
import { CreateBookComponent } from './create-book/create-book.component';
import { CreateMemberComponent } from './create-member/create-member.component';
import { MemberListComponent } from './member-list/member-list.component';
import { SubjectComponent } from './subject/subject.component';

const routes: Routes = [

  {path:'createbook',component:CreateBookComponent},
  {path:'createmember',component:CreateMemberComponent},
  {path:'memberlist',component:MemberListComponent},
  {path:'booklist',component:BookListComponent},
  {path:'subject',component:SubjectComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
