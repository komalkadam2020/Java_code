import { Injectable } from '@angular/core';
import { Book } from 'src/model/book';
import { Member } from 'src/model/member';

@Injectable({
  providedIn: 'root'
})
export class LibraryDataService {

  constructor() { }

  books:Book[]=[
    {bookId:100,title:'Advance Java',subject:'java',author:'Denny'},
    {bookId:200,title:'Advance CPP',subject:'CPP',author:'Jonny'},
    {bookId:300,title:'Learn SQL',subject:'SQL',author:'Sunny'},
  ];

  members:Member[]=[
    {memberId:10,name:"Komal",address:"Pune",issuedBook:null},
    {memberId:20,name:"Ankit",address:"Mumbai",issuedBook:null},
    {memberId:30,name:"Sneha",address:"Nashik",issuedBook:null}
    
  ];

  getAllMembers(){
    return this.members
  }

  addMember(mem:Member):string{
    let pos:number=this.members.findIndex(
      (e) => e.memberId==mem.memberId);
      if(pos == -1){

        this.members.push(mem);
        return `data with id ${mem.memberId} successfully saved`;
      }
      else{
        return `data with id ${mem.memberId} already exist`;
      } 
  }

  deleteMember(mid:number){
    let pos:number=this.members.findIndex( (e) => e.memberId==mid )
    this.members.splice(pos,1)
  }

  getAllBooks(){
    return this.books
  }

  addBook(book:Book):string{
    let pos:number=this.books.findIndex(
      (e) => e.bookId==book.bookId);
      if(pos == -1){

        this.books.push(book);
        return `data with id ${book.bookId} successfully saved`;
      }
      else{
        return `data with id ${book.bookId} already exist`;
      } 
  }

  deleteBook(bId:number){
    let pos:number=this.books.findIndex( (e) => e.bookId==bId )
    this.books.splice(pos,1)
  }


  getAllSubjects(){

    return this.books.findIndex( (e) => e.subject );
  }

  getBookBySubject(subject:string){
    let pos:number=this.books.findIndex( (e) => e.subject==subject )
  }
}
