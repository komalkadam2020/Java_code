import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateBookComponent } from './create-book/create-book.component';
import { CreateMemberComponent } from './create-member/create-member.component';
import { BookListComponent } from './book-list/book-list.component';
import { MemberListComponent } from './member-list/member-list.component';
import { SubjectComponent } from './subject/subject.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    CreateBookComponent,
    CreateMemberComponent,
    BookListComponent,
    MemberListComponent,
    SubjectComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
