import { Component, OnInit } from '@angular/core';
import { Member } from 'src/model/member';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-member-list',
  templateUrl: './member-list.component.html',
  styleUrls: ['./member-list.component.css']
})
export class MemberListComponent implements OnInit {


  members:Member[]=[];

  message:string=''

  constructor(private service:LibraryDataService) { }

  ngOnInit(): void {
    this.members=this.service.getAllMembers();
  }

  deleteMember(mid:number){
    let pos:number=this.members.findIndex( (e) => e.memberId==mid )
    this.members.splice(pos,1)
  }

}
