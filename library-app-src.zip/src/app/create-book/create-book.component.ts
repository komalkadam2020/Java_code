import { Component, OnInit } from '@angular/core';
import { Book } from 'src/model/book';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-create-book',
  templateUrl: './create-book.component.html',
  styleUrls: ['./create-book.component.css']
})
export class CreateBookComponent implements OnInit {

  constructor(private service:LibraryDataService) { }

  ngOnInit(): void {
  }

  message:string=''
  

  showData(data:Book):void {

    console.table(data)
    this.message=this.service.addBook(data);

    setTimeout(() => {this.message=''},2000 )
   
  }
}
