import { Component, OnInit } from '@angular/core';
import { Book } from 'src/model/book';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  books:Book[]=[];
  message:string=''

  constructor(private service:LibraryDataService) { }

  ngOnInit(): void {
    this.books=this.service.getAllBooks();
  }

  
  deleteBook(bId:number){
    let pos:number=this.books.findIndex( (e) => e.bookId==bId )
    this.books.splice(pos,1)
  }


}
