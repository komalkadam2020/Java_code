import { Book } from "./book";

export interface Member{

    memberId:number;
	name:string;
	address:string;
	issuedBook:Book | null;
}