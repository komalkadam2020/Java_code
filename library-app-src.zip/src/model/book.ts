export interface Book{

     bookId:number;
	 title:string;
	 subject:string;
	 author:string;
}