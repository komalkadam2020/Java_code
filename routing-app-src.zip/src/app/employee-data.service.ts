import { Injectable } from '@angular/core';
import { Employee } from 'src/model/employee';

@Injectable({
  providedIn: 'root'
})

export class EmployeeDataService {

  employees:Employee[]=
  [
    {empId:100,name:'Komal ',salary:30000,gender:'F' },
    {empId:200,name:'Ankita ',salary:20000 ,gender:'F'},
    {empId:300,name:' Rohan',salary:33000,gender:'M' },
    {empId:400,name:'Shubham ',salary:23000 ,gender:'M'},
    {empId:500,name:'Akash',salary:35000,gender:'M' },
   
  ]


  //to get all employees
  getAllEmployees(){
    return this.employees
  }

  //to get one employee
  getEmployee(eid:number):Promise<any>{
    let pos:number=this.employees.findIndex( (e) => e.empId==eid );
    
    return new Promise(
      (success,fail) => {
        if(pos != -1)
            success(this.employees[pos])
        else
            fail(`Employee with id ${eid} not found..!!`)
      }
    );
    
  }

  deleteEmployee(eid:number){
    let pos:number=this.employees.findIndex( (e) => e.empId==eid )
    this.employees.splice(pos,1)
  }

  updateEmployee(emp:Employee){
    let pos:number=this.employees.findIndex( (e) => e.empId==emp.empId )
   
    if(pos != -1){

      this.employees[pos]=emp;
      return `data with id ${emp.empId} successfully updated`;
    }
    else{
      return `data with id ${emp.empId} not found`;
    }
  }

  addEmployee(emp:Employee):string{

    let pos:number=this.employees.findIndex(
      (e) => e.empId==emp.empId);
      if(pos == -1){

        this.employees.push(emp);
        return `data with id ${emp.empId} successfully saved`;
      }
      else{
        return `data with id ${emp.empId} already exist`;
      }

  }

}



