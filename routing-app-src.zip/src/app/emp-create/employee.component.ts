import { Component, EventEmitter, OnInit, Output } from '@angular/core';

import { Employee } from 'src/model/employee';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'add-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmpCreateComponent  {

 
 constructor(private service:EmployeeDataService){}

 message:string=''
 

  showData(data:Employee):void {

    console.table(data)
    this.message=this.service.addEmployee(data);

    setTimeout(() => {this.message=''},5000 )
   
  }


}

