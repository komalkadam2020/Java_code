export interface Teacher{
    teacherId:number
    teacherName:string
    specification:string
    teacherEmail:string

}