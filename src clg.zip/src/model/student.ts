import { Teacher } from "./teacher";

export interface Student{
    studentId:number
    studentName:string
    studentFee:number
    studentGender:string
    studentBranch:string
    studentEmail:string
    teacher:Teacher|null

}