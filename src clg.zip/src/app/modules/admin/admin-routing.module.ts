import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ServicesComponent } from './components/services/services.component';
import { ContactComponent } from './components/contact/contact.component';
import { CreateStudentComponent } from './components/college/create-student/create-student.component';
import { StudentListComponent } from './components/college/student-list/student-list.component';
import { UpdateStudentComponent } from './components/college/update-student/update-student.component';
import { TeacherListComponent } from './components/college/teacher-list/teacher-list.component';
import { UpdateTeacherComponent } from './components/college/update-teacher/update-teacher.component';
import { CreateTeacherComponent } from './components/college/create-teacher/create-teacher.component';

const routes: Routes = [
  {
    path: '',
    component: AdminDashboardComponent,
    children: [
      { path: 'home', component: HomeComponent },
      { path: 'about', component: AboutComponent },
      { path: 'services', component: ServicesComponent },
      { path: 'contact', component: ContactComponent },
      { path: 'create-student', component: CreateStudentComponent },
      { path: 'list-student', component: StudentListComponent },
      { path: 'update-student', component: UpdateStudentComponent },
      { path: 'create-teacher', component:  CreateTeacherComponent},
      { path: 'list-teacher', component: TeacherListComponent },
      { path: 'update-teacher', component: UpdateTeacherComponent },
      { path: '', redirectTo: '/admin/home', pathMatch: 'full' },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
