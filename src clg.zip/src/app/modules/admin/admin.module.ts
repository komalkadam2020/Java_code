import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { ContactComponent } from './components/contact/contact.component';
import { ServicesComponent } from './components/services/services.component';
import { AboutComponent } from './components/about/about.component';
import { CreateStudentComponent } from './components/college/create-student/create-student.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient} from '@angular/common/http';
import { AppComponent } from 'src/app/app.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { StudentListComponent } from './components/college/student-list/student-list.component';
import { TeacherListComponent } from './components/college/teacher-list/teacher-list.component';
import { UpdateStudentComponent } from './components/college/update-student/update-student.component';
import { UpdateTeacherComponent } from './components/college/update-teacher/update-teacher.component';
import { StudentComponent } from './components/college/student/student.component';
import { CreateTeacherComponent } from './components/college/create-teacher/create-teacher.component';


@NgModule({
  declarations: [
    AdminDashboardComponent, 
    HeaderComponent, 
    FooterComponent, 
    HomeComponent, 
    ContactComponent, 
    ServicesComponent, 
    AboutComponent,
    CreateStudentComponent,
    StudentListComponent,
    TeacherListComponent,
    UpdateStudentComponent,
    UpdateTeacherComponent,
    StudentComponent,
    CreateTeacherComponent,
    
  ],
  imports: [CommonModule, 
    AdminRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
    
    

  ],
  providers: [],
 
})
export class AdminModule { }
