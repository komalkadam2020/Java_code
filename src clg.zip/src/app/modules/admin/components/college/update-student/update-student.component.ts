import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CollegeDataService } from 'src/college-data.service';
import { Student } from 'src/model/student';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.scss']
})
export class UpdateStudentComponent implements OnInit {


  
  message: string = ''

  students: Student[] = [];

  stud: Student = { studentId: 0, studentName: '', studentFee: 0, studentGender: '', studentBranch: '', studentEmail: '', teacher: { teacherId: 10, teacherName: '', specification: '', teacherEmail: '' } }


  constructor(private service: CollegeDataService, private route: ActivatedRoute,
    private router: Router) { }


  ngOnInit(): void {


    this.route.paramMap.subscribe(params => {
      let sidstr: string | null = params.get("studentId");
      if (sidstr == null) {

      }
      else {
        let sid = parseInt(sidstr); //+eidstr
        this.service.getStudent(sid).subscribe(

          (response) => {
            this.stud = response.message
          },
          (errorResponse) => {
            this.message = errorResponse.error.message
            setTimeout(() => {
              this.router.navigate(['/list-student'])
            }, 2000);
          }
        )
      }
    });
  }

  saveData(data: Student) {

    this.service.updateStudent(data).subscribe(

      (response) => {
        this.message = response.message, this.ngOnInit()
        setTimeout(() => {
          this.router.navigate(['/list-student', this.stud.studentId])
        }, 2000);
      },
      (errorResponse) => {
        this.message = errorResponse.error.message;
        setTimeout(() => {
          this.router.navigate(['/list-student', this.stud.studentId])
        }, 2000);
      }
    );

  }


}
