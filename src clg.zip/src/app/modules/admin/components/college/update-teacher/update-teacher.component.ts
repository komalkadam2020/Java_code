import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { CollegeDataService } from 'src/college-data.service';
import { Teacher } from 'src/model/teacher';

@Component({
  selector: 'app-update-teacher',
  templateUrl: './update-teacher.component.html',
  styleUrls: ['./update-teacher.component.scss']
})
export class UpdateTeacherComponent implements OnInit {

  

  
  message: string = ''

  teachers: Teacher[] = [];

  teacher: Teacher = { teacherId: 0, teacherName: '', specification: '', teacherEmail: '' }


  
  constructor(private service: CollegeDataService, private route: ActivatedRoute,
    private router: Router) { }


  ngOnInit(): void {


    this.route.paramMap.subscribe(params => {
      let sidstr: string | null = params.get("teacherId");
      if (sidstr == null) {

      }
      else {
        let sid = parseInt(sidstr); //+eidstr
        this.service.getStudent(sid).subscribe(

          (response) => {
            this.teacher = response.message
          },
          (errorResponse) => {
            this.message = errorResponse.error.message
            setTimeout(() => {
              this.router.navigate(['/list-teacher'])
            }, 2000);
          }
        )
      }
    });
  }

  saveData(data: Teacher) {

    this.service.updateTeacher(data).subscribe(

      (response) => {
        this.message = response.message, this.ngOnInit()
        setTimeout(() => {
          this.router.navigate(['/list-teacher', this.teacher.teacherId])
        }, 2000);
      },
      (errorResponse) => {
        this.message = errorResponse.error.message;
        setTimeout(() => {
          this.router.navigate(['/list-teacher', this.teacher.teacherId])
        }, 2000);
      }
    );

  }


}
 



























/*
  model: any = {};
  model2: any = {};
  edit = false;
  add = false;
  create = true;
  Show = false;
  myValue: any;
  ngOnInit() {
    this.model = new FormGroup({
      'name': new FormControl(this.model.name, [
        Validators.required,
        Validators.minLength(4),
      ]),
      'position': new FormControl(this.model.position),
      'salary': new FormControl(this.model.salary, Validators.required)
    });
  }
  title = 'Employee Details';
  employees = [{teacherId:100, name: "Sunil", position: "Developer", salary: 20000 },
  { teacherId:200,name: "Vamshi", position: "Java Developer", salary: 30000 },
  {teacherId:300, name: "Chethan", position: ".Net Developer", salary: 10000 }];

  

  createEmp() {
    this.add = true;
    this.create = false;
    this.Show = false;
    this.edit = false;
  }
  addEmployee() {

   // this.service.updateTeacher(data).subscribe(

    
        console.log()
       this.employees.push(this.model);
        this.Show = true;
        this.add = false;
        this.model = {};

     
  

   
  }

  deleteEmployee(i: any) {
    this.employees.splice(i, 1)
    this.Show = true;
    console.log(i);
  }
  editEmployee(k: any) {
    this.edit = true;
    this.Show = false;
    this.add = false;
    //if(name!="")
    // {
    // this.model2.name = this.employees[k].name;
    //}
    this.model2.position = this.employees[k].position;
    this.model2.salary = this.employees[k].salary;
    this.myValue = k;
  }
  updateEmployee() {
    this.Show = true;
    this.edit = false;
    let k = this.myValue;
    for (let i = 0; i < this.employees.length; i++) {
      if (i == k) {
        this.employees[i] = this.model2;
        this.model2 = {};
      }
    }
  }

}

*/
















