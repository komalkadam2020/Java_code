import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CollegeDataService } from 'src/college-data.service';
import { Student } from 'src/model/student';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.scss']
})
export class StudentListComponent implements OnInit {

  constructor(private studentservice:CollegeDataService,private route: ActivatedRoute,
    private router: Router) { }  
  
    
  deleteMessage=false;
   
  message:string=''
  
    stud:Student={studentId:0, studentName:'', studentFee:0, studentGender:'',studentBranch:'',studentEmail:'',teacher:{teacherId:0, teacherName:'', specification:'', teacherEmail:''}}

 students: Student[]=[];  
  
  ngOnInit() {  
        
    this.studentservice.getAllStudent().subscribe(data =>{ 
    this.students =data;  
      
    })  
  }  
    
  deleteStudent(id: number) {  
    this.studentservice.deleteStudent(id)  
      .subscribe(  
        data => {  
          console.log(data);
          setTimeout(() => { this.message='' }, 2000); 
         this.deleteMessage=true;  
          this.studentservice.getAllStudent().subscribe(data =>{  
            this.students =data  
           
            })  
        },  
        error => console.log(error));  
  }  

 

}
