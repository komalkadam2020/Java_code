export interface Person{
    name:string;
    age:number;
    city:string;
}