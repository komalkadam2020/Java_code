import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { cityList } from 'src/assets/model/cityData';
import { Person } from 'src/assets/model/person';

@Component({
  selector: 'app-add-emp4',
  templateUrl: './add-emp4.component.html',
  styleUrls: ['./add-emp4.component.css']
})
export class AddEmp4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.cities = cityList;
  }


  cities: string[] = [];


  personForm:FormGroup=new FormGroup(
    {

    name:new FormControl('',[Validators.required,Validators.minLength(3)]),
    age:new FormControl('',[Validators.required,Validators.min(21)]),
    city:new FormControl('',[Validators.required]),

  }
  );

  saveData(): void {

    console.log(this.personForm.value)
  }

  get f(){

    return this.personForm.controls;

  }

}
