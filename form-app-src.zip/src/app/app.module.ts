import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AddEmp1Component } from './add-emp1/add-emp1.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddEmp2Component } from './add-emp2/add-emp2.component';
import { AddEmp3Component } from './add-emp3/add-emp3.component';
import { AddEmp4Component } from './add-emp4/add-emp4.component';

@NgModule({
  declarations: [
    AppComponent,
    AddEmp1Component,
    AddEmp2Component,
    AddEmp3Component,
    AddEmp4Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
