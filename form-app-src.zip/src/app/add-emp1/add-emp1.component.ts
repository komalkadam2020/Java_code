import { Component, OnInit } from '@angular/core';
import { cityList } from 'src/assets/model/cityData';
import { Person } from 'src/assets/model/person';

@Component({
  selector: 'app-add-emp1',
  templateUrl: './add-emp1.component.html',
  styleUrls: ['./add-emp1.component.css']
})
export class AddEmp1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.cities=cityList
  }


cities:string[]=[]
  person:Person={name:'',age:0,city:''}

  saveData():void{
    console.log(this.person)
  }

}
