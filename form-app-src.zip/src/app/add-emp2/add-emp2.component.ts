import { Component, OnInit } from '@angular/core';
import { cityList } from 'src/assets/model/cityData';
import { Person } from 'src/assets/model/person';

@Component({
  selector: 'app-add-emp2',
  templateUrl: './add-emp2.component.html',
  styleUrls: ['./add-emp2.component.css']
})
export class AddEmp2Component implements OnInit {

  constructor() { }
  ngOnInit(): void {
    this.cities = cityList
  }


  cities: string[] = []


  saveData(name: string, age: any, city: string): void {

    let person: Person = { name, age, city }
    console.log()
  }

}
