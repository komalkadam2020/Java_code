import { Component, OnInit } from '@angular/core';
import { cityList } from 'src/assets/model/cityData';
import { Person } from 'src/assets/model/person';

@Component({
  selector: 'app-add-emp3',
  templateUrl: './add-emp3.component.html',
  styleUrls: ['./add-emp3.component.css']
})
export class AddEmp3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.cities = cityList;
  }


  cities: string[] = [];


  saveData(data: Person): void {

    console.log(data)
  }

}
