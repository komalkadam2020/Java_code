import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  selectedId:number=0;
  formsData=[

    {id:1,detail:'input using ngModel two way binding'},
    {id:2,detail:'input using template variable'},
    {id:3,detail:'input using Template Driven form'},
    {id:4,detail:'input using Reactive form'},

  ];


}
