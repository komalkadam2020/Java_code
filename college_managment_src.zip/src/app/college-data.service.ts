import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from 'src/model/student';
import { Teacher } from 'src/model/teacher';

@Injectable({
  providedIn: 'root'
})
export class CollegeDataService {

  student: Student[] = [  ];
  teacher: Teacher[] = [  ];

  constructor(private http:HttpClient){
    
  }
  
  studentUrl:string='http://localhost:9090/students';
  teacherUrl:string='http://localhost:9090/teachers';
  // to get all students
  getAllStudent() :Observable<any> {
    return this.http.get(this.studentUrl);
  }

  //to get all teachers
  getAllTeacher() :Observable<any> {
    return this.http.get(this.teacherUrl);
  }

  // to get one student
  getStudent(eid: number):Observable<any> {
    return this.http.get(`${this.studentUrl}/${eid}`);
  }
  
    // to get one teacher
  getTeacher(eid: number):Observable<any> {
    return this.http.get(`${this.teacherUrl}/${eid}`);
  }

  deleteStudent(eid: number):Observable<any> {
    return this.http.delete(`${this.studentUrl}/${eid}`);
  }

  deleteTeacher(eid: number):Observable<any> {
    return this.http.delete(`${this.teacherUrl}/${eid}`);
  }


  updateStudent(emp:Student):Observable<any> {
    return this.http.put(this.studentUrl,emp);
  }

  updateTeacher(emp:Teacher):Observable<any> {
    return this.http.put(this.teacherUrl,emp);
  }

  addStudent(emp: Student): Observable<any> {
   return this.http.post(this.studentUrl,emp);
  
}

addTeacher(emp: Teacher): Observable<any> {
  return this.http.post(this.teacherUrl,emp);
 
}
}
