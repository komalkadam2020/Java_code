import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Teacher } from 'src/model/teacher';
import { CollegeDataService } from '../college-data.service';

@Component({
  selector: 'app-create-teacher',
  templateUrl: './create-teacher.component.html',
  styleUrls: ['./create-teacher.component.css']
})
export class CreateTeacherComponent implements OnInit {
 
  submitted = false; 
  message:string=''

  
  constructor(private service:CollegeDataService){}
  ngOnInit() {  
    this.submitted=false;  
  }  
  
  teachersaveform=new FormGroup({  
    teacher_name:new FormControl('' , [Validators.required , Validators.minLength(5) ] ),  
    teacher_email:new FormControl('',[Validators.required,Validators.email]),  
    teacher_branch:new FormControl()  
  });  


  
 
   saveData(data:Teacher) {
 
     this.service.addTeacher(data).subscribe(
 
       (response) => {
         this.message=response.message 
         setTimeout(() => { this.message='' }, 2000);
       },
       (errorResponse) => {
          this.message=errorResponse.error.message
           setTimeout(() => { this.message=''}, 2000);
       }
     );
   }

   addTeacherForm(){  
    this.submitted=false;  
    this.teachersaveform.reset();  
  }  

}
