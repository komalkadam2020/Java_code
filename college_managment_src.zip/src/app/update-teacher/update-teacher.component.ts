import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Teacher } from 'src/model/teacher';
import { CollegeDataService } from '../college-data.service';

@Component({
  selector: 'app-update-teacher',
  templateUrl: './update-teacher.component.html',
  styleUrls: ['./update-teacher.component.css']
})
export class UpdateTeacherComponent implements OnInit {
 


  message: string = ''

  teachers: Teacher[] = [];

  teacher: Teacher = { teacherId: 0, teacherName: '', specification: '', teacherEmail: '' }


  
  constructor(private service: CollegeDataService, private route: ActivatedRoute,
    private router: Router) { }


  ngOnInit(): void {


    this.route.paramMap.subscribe(params => {
      let sidstr: string | null = params.get("teacherId");
      if (sidstr == null) {

      }
      else {
        let sid = parseInt(sidstr); //+eidstr
        this.service.getStudent(sid).subscribe(

          (response) => {
            this.teacher = response.message
          },
          (errorResponse) => {
            this.message = errorResponse.error.message
            setTimeout(() => {
              this.router.navigate(['/list-teacher'])
            }, 2000);
          }
        )
      }
    });
  }

  saveData(data: Teacher) {

    this.service.updateTeacher(data).subscribe(

      (response) => {
        this.message = response.message, this.ngOnInit()
        setTimeout(() => {
          this.router.navigate(['/list-teacher', this.teacher.teacherId])
        }, 2000);
      },
      (errorResponse) => {
        this.message = errorResponse.error.message;
        setTimeout(() => {
          this.router.navigate(['/list-teacher', this.teacher.teacherId])
        }, 2000);
      }
    );

  }


}


