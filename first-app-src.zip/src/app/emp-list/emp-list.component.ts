import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/model/employee';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  employees: Employee[] = []

  creating: boolean = false;
  empId:number=0
  display: boolean = false
  message: string='';
 

  constructor(private service: EmployeeDataService) {

  }
  ngOnInit(): void {
    
    this.getAll();
  }

  getEmployee(eid: number): void {

    
   this.empId=eid; 
   this.display = true

  }

  createCompleted(){
    this.creating=false;
  }

  dataDeleted(message:string){
    this.message=message;
    this.display=false;

    setTimeout( () => this.message='',5000)

  }

  hideEmployee(){
    this.display=false;
  }

  

  getAll() {
  
   this.employees = this.service.getAllEmployees();

  }




}

/*
  employees:Employee[]=
  [
    /*{empId:100,name:'Komal ',salary:30000,gender:'F',dob:new Date("30-05-1999") },
    {empId:200,name:'Ankita ',salary:20000 ,gender:'F',dob:new Date("18-04-1998")},
    {empId:300,name:' Rohan',salary:33000,gender:'M',dob:new Date("01-10-1999") },
    {empId:400,name:'Shubham ',salary:23000 ,gender:'M',dob:new Date("08-05-1995")},
    {empId:500,name:'Akash',salary:35000,gender:'M',dob:new Date("30-11-1999") },
   
  ]

  
  display:boolean=false
  //date:Date=new Date()

  constructor(private service:EmployeeDataService){
    
  }
  ngOnInit(): void {
   // this.employees=this.service.getAllEmployees() 
  this.getAll();
  }

  

  selectedEmployee:Employee={empId:0,name:'',salary:0,gender:'',dob:new Date('')}

  getEmployee(eid:number):void{

   //let position:number= this.employees.findIndex((e) => e.empId == eid)

   this.selectedEmployee=this.service.getEmployee(eid)
    this.display=true

  }

  deleteEmp(){

    this.service.deleteEmployee(this.selectedEmployee.empId)
    this.getAll();
    this.display=false
  }
  
  getAll(){
    this.employees=[...this.service.getAllEmployees()]

  }

}


deleteEmp() {

    this.service.deleteEmployee(this.selectedEmployee.empId)
    this.getAll();
    this.display = false
  }
*/