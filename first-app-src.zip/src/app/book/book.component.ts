import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent  {


  bookId:number=0;
  title:string='';
  author:string=''
  price:number=0
 
  message:string=''

  ValidData:boolean=false;

  getData(bookData:string):void{

    this.ValidData=false;
    this.message=''
    let flds:string[]=bookData.split(",");

    if(flds.length!=4){
       this.message="Invalid Data"
      return
    }

    let id:number=parseInt(flds[0]) 
    if(isNaN(id)){
      this.message="Invalid Price"
      return
    }

    let prc:number=parseFloat(flds[3])
    if(isNaN(prc)){
      this.message="Invalid Id"
      return
    }

    this.bookId=id;
    this.title=flds[1];
    this.author=flds[2];
    this.price=prc
    this.ValidData=true

  }

 


}
