import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
  show:boolean=true
greet1:string='Hello Good morning';
greet2:string='Have nice Day..'

actionTaken(childMessage:string){

  console.log(`child says ${{childMessage}}`)
  this.show=false
}

}
