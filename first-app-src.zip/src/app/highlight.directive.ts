import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[highlight]'
})



export class HighlightDirective {

  @Input() color:string=''
  constructor(private elf:ElementRef) {

   }

   @HostListener("mouseover")
   changeTextColor():void{

    this.elf.nativeElement.style.backgroundColor=this.color
    this.elf.nativeElement.style.Color='white'
   }

   @HostListener("mouseleave")
   restTextColor():void{

    this.elf.nativeElement.style.backgroundColor='lightgrey'
    this.elf.nativeElement.style.Color='black'
   }

}
