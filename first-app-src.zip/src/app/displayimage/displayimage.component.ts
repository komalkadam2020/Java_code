import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displayimage',
  templateUrl: './displayimage.component.html',
  styleUrls: ['./displayimage.component.css']
})
export class DisplayimageComponent  {

  position=0;
  images=['nature','city','river','girl','plane']
 
  imageName=this.images[0]
 
  imageUrl=`./assets/${this.imageName}.jpg`
 
  
 
  getPrevImage(){
   
     this.position--;
     this.Changedetails()
   
   }
 
  getNextImage(){
   
     this.position++;
     this.Changedetails()
   
  }
 
  Changedetails(){
 
   this.imageName=this.images[this.position]
     this.imageUrl=`./assets/${this.imageName}.jpg`
 
  }
 
}
