import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipetest',
  templateUrl: './pipetest.component.html',
  styleUrls: ['./pipetest.component.css']
})
export class PipetestComponent  {

  text:string='initial text'

  today:Date=new Date()
 
  emp={empid:100,name:'kk',salary:33000}

}
