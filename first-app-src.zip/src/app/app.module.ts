import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import { DisplayimageComponent } from './displayimage/displayimage.component';
import { PipetestComponent } from './pipetest/pipetest.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmpListComponent } from './emp-list/emp-list.component';
import { PowerPipe } from './power.pipe';
import { HighlightDirective } from './highlight.directive';
import { DisplayComponent } from './display/display.component';
import { EmpDetailsComponent } from './emp-details/emp-details.component';


@NgModule({
  declarations: [
    AppComponent,
    BookComponent,
    DisplayimageComponent,
    PipetestComponent,
    EmployeeComponent,
    EmpListComponent,
    PowerPipe,
    HighlightDirective,
    DisplayComponent,
    EmpDetailsComponent,
    
    
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
