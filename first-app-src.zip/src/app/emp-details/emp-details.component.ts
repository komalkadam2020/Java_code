import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Employee } from 'src/model/employee';

import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-emp-details',
  templateUrl: './emp-details.component.html',
  styleUrls: ['./emp-details.component.css']
})
export class EmpDetailsComponent implements OnInit {


  @Input() empId:number=0;
  @Output() done=new EventEmitter()
  @Output() deleted=new EventEmitter()
  
  emp:Employee={empId:0,name:'',salary:0,gender:''};

  
  constructor(private service:EmployeeDataService) { }

  ngOnInit(): void {
    this.emp=this.service.getEmployee(this.empId);  //when component display
  }

  completed(){
      this.done.emit()

  }

  deleteEmp(){
    this.service.deleteEmployee(this.empId)
    this.deleted.emit(`Employee with id ${this.empId} deleted`);

  }

}
