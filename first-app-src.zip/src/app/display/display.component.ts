import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {


  @Input() message1?:string=' my message 1'
  @Input() message2?:string=' my message 2'
  @Output() done=new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

//reply:string=''

  completed(){

    let reply=`Thanks for your greeting ${this.message1} and ${this.message2}`
    this.done.emit(reply);
  }

}
