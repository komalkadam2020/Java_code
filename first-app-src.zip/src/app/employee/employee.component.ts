import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { EMPTY } from 'rxjs';
import { Employee } from 'src/model/employee';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'add-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent  {



 @Output() done=new EventEmitter()
 
 constructor(private service:EmployeeDataService){}

 message:string=''
 //creating: boolean = false;


  showData(data:Employee):void {

    console.table(data)
    this.message=this.service.addEmployee(data);

    setTimeout(() => {this.message=''},5000 )
   
  }

  completed(){
    this.done.emit();
  }

 



  /*

  empl:Employee={
      empId:100,
      name:'Komal Kadam',
      salary:30000,
      gender:'F',
      dob:new Date("05-30-1999")
      

  }

  show:boolean=false
 
  showData(a:string,b:string,c:string,d:string,e:string){

    let empId=parseInt(a)
    let name=b;
    let salary=parseInt(c)
    let gender=d
    let dob=new Date(e)
    this.empl={empId,name,salary,gender,dob}
    this.show=true


  }
*/

  }
  


