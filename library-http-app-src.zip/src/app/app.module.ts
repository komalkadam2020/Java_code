import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateBookComponent } from './create-book/create-book.component';
import { CreateMemberComponent } from './create-member/create-member.component';
import { BookListComponent } from './book-list/book-list.component';
import { MemberListComponent } from './member-list/member-list.component';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { IssueBookComponent } from './issue-book/issue-book.component';
import { ReturnBookComponent } from './return-book/return-book.component';
import { SubjectComponent } from './issue_Return_book/subject.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateBookComponent,
    CreateMemberComponent,
    BookListComponent,
    MemberListComponent,
    SubjectComponent,
    IssueBookComponent,
    ReturnBookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
