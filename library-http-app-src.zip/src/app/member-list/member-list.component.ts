import { Component, OnInit } from '@angular/core';
import { Member } from 'src/model/member';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-member-list',
  templateUrl: './member-list.component.html',
  styleUrls: ['./member-list.component.css']
})
export class MemberListComponent implements OnInit {


  members:Member[]=[];

  message:string=''

  constructor(private service:LibraryDataService) { }

  ngOnInit(): void {
    this.service.getAllMembers().subscribe(

      (list) => {this.members=list},
      (error) =>{console.log(error)}

    );
    
  }

  delete(mid:number){
    this.service.deleteMember(mid).subscribe(

      (response) =>{this.message=response.message,this.ngOnInit()
        setTimeout(() => { this.message='' }, 3000);
      },
      (errorResponse)=> {this.message=errorResponse.error.message
        setTimeout(() => { this.message='' }, 3000);
      }
     )
  }

}


