import { Component, OnInit } from '@angular/core';

import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-issue-book',
  templateUrl: './issue-book.component.html',
  styleUrls: ['./issue-book.component.css']
})
export class IssueBookComponent implements OnInit {

 // members:Member[]=[];
  message:string=''

  constructor(private service:LibraryDataService) { }

  ngOnInit(): void {
    
  }

  issueBook(bookId:number,memberId:number){
    this.service.issueBook(bookId,memberId).subscribe(
 
     (response:any) =>{this.message=response.message
       setTimeout(() => { this.message='' }, 2000);
     },
     (errorResponse)=> {this.message=errorResponse.error.message
       setTimeout(() => { this.message='' }, 2000);
     }
    )
   }


}
