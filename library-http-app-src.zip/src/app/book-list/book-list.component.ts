import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Book } from 'src/model/book';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  //books:Book={bookId:0, title:'',author:'', subject:''}
  books:Book[]=[];
  message:string=''
  subjects:string[]=[];
  subject:string=''


  constructor(private service:LibraryDataService,private http:HttpClient) { }

  ngOnInit(): void {

    this.loadData();
    
  }

  deleteB(bId:number){
    this.service.deleteBook(bId).subscribe(
 
     (response) =>{this.message=response.message, this.loadData();
       setTimeout(() => { this.message='' }, 3000);
     },
     (errorResponse)=> {this.message=errorResponse.error.message
       setTimeout(() => { this.message='' }, 3000);
     }
    )
   }


  loadData(){

    if(this.subject==''){

      this.service.getAllBooks().subscribe(
        
      (list:any) => {this.books=list},
      (error) =>{console.log(error)}

      )
    }
    else{
      this.service.getBooksBySubject(this.subject).subscribe(
  
        (list:any) => {this.books=list},
        (error) =>{console.log(error)}
  
      )
    }


    this.service.getAllSubjects().subscribe(
      (list:any) => {this.subjects=list},
      (error) => {console.log(error)}
    )

  }



}
