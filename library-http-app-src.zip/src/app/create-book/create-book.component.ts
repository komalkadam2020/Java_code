import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Book } from 'src/model/book';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-create-book',
  templateUrl: './create-book.component.html',
  styleUrls: ['./create-book.component.css']
})
export class CreateBookComponent  {

  constructor(private service:LibraryDataService) { }


  message:string=''
  

  showBookData(data:Book):void {

    this.service.saveBook(data).subscribe(

      (response) => {
        this.message=response.message 
        setTimeout(() => { this.message=''}, 2000);
      },
      (errorResponse) => {
         this.message=errorResponse.error.message
          setTimeout(() => { this.message=''}, 2000);
      }
    );
  }
}
