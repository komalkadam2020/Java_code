import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookListComponent } from './book-list/book-list.component';
import { CreateBookComponent } from './create-book/create-book.component';
import { CreateMemberComponent } from './create-member/create-member.component';
import { IssueBookComponent } from './issue-book/issue-book.component';
import { MemberListComponent } from './member-list/member-list.component';
import { ReturnBookComponent } from './return-book/return-book.component';
import { SubjectComponent } from './issue_Return_book/subject.component';


const routes: Routes = [

  {path:'createbook',component:CreateBookComponent},
  {path:'createmember',component:CreateMemberComponent},
  {path:'memberlist',component:MemberListComponent},
  {path:'',component:BookListComponent},
  {path:'issue_return',component:SubjectComponent},
  {path:'issuebook',component:IssueBookComponent},
  {path:'returnbook',component:ReturnBookComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
