import { Injectable, TemplateRef } from '@angular/core';
import { Book } from 'src/model/book';
import { Member } from 'src/model/member';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LibraryDataService {

  constructor(private http:HttpClient) { }

  bookUrl: string = 'http://localhost:9090/books';
  memberUrl: string = 'http://localhost:9090/members';

  getAllBooks() :Observable<any>{
      return this.http.get(this.bookUrl)
  }

  getBooksBySubject(subject:string):Observable<any>{
    return this.http.get(`${this.bookUrl}/getAll/${subject}`)
  }

  getAllMembers(): Observable<any>{
    return this.http.get(this.memberUrl);
  }

  deleteBook(bookId:number):Observable<any>{
    return this.http.delete(`${this.bookUrl}/${bookId}`)
  }
  deleteMember(memberId:number):Observable<any>{
    return this.http.delete(`${this.memberUrl}/${memberId}`)
  }

  getAllSubjects():Observable<any>{
    return this.http.get(`${this.bookUrl}/getSubjects`)
  }

  saveBook(book:Book):Observable<any>{

    return this.http.post(`${this.bookUrl}`,book)
  }

  saveMember(member:Member):Observable<any>{

    return this.http.post(`${this.memberUrl}`,member)
  }

  issueBook(bookId:number,memberId:number):Observable<any>{

    return this.http.put(`${this.bookUrl}/issue/${memberId}/${bookId}`,null)
  }

  returnBook(bookId:number,memberId:number):Observable<any>{

    return this.http.put(`${this.bookUrl}/return/${memberId}/${bookId}`,null)
  }
 
}






















/*
  bookUrl:string='http://localhost:9090/books';
  memberUrl:string='http://localhost:9090/members';

  books:Book[]=[
    {bookId:100,title:'Advance Java',subject:'java',author:'Denny'},
    {bookId:200,title:'Advance CPP',subject:'CPP',author:'Jonny'},
    {bookId:300,title:'Learn SQL',subject:'SQL',author:'Sunny'},
  ];

 

  getAllMembers():Observable<any>{
    return this.http.get(this.memberUrl)
  }

  createMember(mem:Member):Observable<any>{
    return this.http.post(this.memberUrl,mem);
    
  }

  deleteMember(mid:number):Observable<any>{
    return this.http.delete(`${this.memberUrl}/${mid}`);
  }

  getAllBooks(){
    return this.books
  }

  createBook(book:Book):string{
    let pos:number=this.books.findIndex(
      (e) => e.bookId==book.bookId);
      if(pos == -1){

        this.books.push(book);
        return `data with id ${book.bookId} successfully saved`;
      }
      else{
        return `data with id ${book.bookId} already exist`;
      } 
  }

  deleteBook(bId:number){
    let pos:number=this.books.findIndex( (e) => e.bookId==bId )
    this.books.splice(pos,1)
  }


  getAllSubjects(){

    return this.books.findIndex( (e) => e.subject );
  }

  getBookBySubject(subject:string){
    let pos:number=this.books.findIndex( (e) => e.subject==subject )
  }
}
*/