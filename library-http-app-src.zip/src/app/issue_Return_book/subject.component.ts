import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from 'src/model/book';
import { Member } from 'src/model/member';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.css']
})
export class SubjectComponent implements OnInit {
  constructor(private service:LibraryDataService,private router:Router) { }

  books:Book[]=[];
  members:Member[]=[];
  message:string='';
  issue:boolean=false;
  return:boolean=false;
  memberId:number=0;
  bookId:number=0;
   ngOnInit(): void 
   {
    this.getData();
    this.getMembers();
     
    }
    getData(){
    this.service.getAllBooks().subscribe(
        
      (response) => {this.books=response},
      (errorResponse) =>{this.members=errorResponse.error.message}

      )
    }
    getMembers(){
      this.service.getAllMembers().subscribe(
        
        (response) => {this.members=response},
        (errorResponse) =>{this.message=errorResponse.error.message}
  
        )
      }

    save()
    {
      if(this.issue)
      {
        this.service.issueBook(this.bookId,this.memberId).subscribe(
 
          (response:any) => {
            this.message=response.message
            setTimeout(() => { 
              this.router.navigate(["memberlist"])}, 2000);
          },
          (errorResponse)=> { 
            this.message=errorResponse.error.message
            setTimeout(() => 
              { this.message='' }, 2000);
          }
         )
         this.issue=false;
      }
      else
      {
        this.service.returnBook(this.bookId,this.memberId).subscribe(
 
          (response:any) => {
            this.message=response.message
            setTimeout(() => { 
              this.router.navigate(["memberlist"])}, 2000);
          },
          (errorResponse)=> { 
            this.message=errorResponse.error.message
            setTimeout(() => 
              { this.message='' }, 2000);
          }
         )
         this.return=false;
      }
    }

}



  


