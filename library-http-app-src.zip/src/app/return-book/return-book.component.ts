import { Component, OnInit } from '@angular/core';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-return-book',
  templateUrl: './return-book.component.html',
  styleUrls: ['./return-book.component.css']
})
export class ReturnBookComponent implements OnInit {

 // members:Member[]=[];
 message:string=''

 constructor(private service:LibraryDataService) { }

 ngOnInit(): void {
   
 }

 returnBook(bookId:number,memberId:number){
   this.service.returnBook(bookId,memberId).subscribe(

    (response:any) =>{this.message=response.message
      setTimeout(() => { this.message='' }, 3000);
    },
    (errorResponse)=> {this.message=errorResponse.error.message
      setTimeout(() => { this.message='' }, 3000);
    }
   )
  }
}
