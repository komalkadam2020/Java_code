import { Component, OnInit } from '@angular/core';
import { Member } from 'src/model/member';
import { LibraryDataService } from '../library-data.service';

@Component({
  selector: 'app-create-member',
  templateUrl: './create-member.component.html',
  styleUrls: ['./create-member.component.css']
})
export class CreateMemberComponent {

  constructor(private service:LibraryDataService) { }
  
  
  

  message:string=''
  

  showData(data:Member):any {

    this.service.saveMember(data).subscribe(

      (response) => {
        this.message=response.message
        setTimeout(() => { this.message='' }, 2000);
      },
      (errorResponse) => {
         this.message=errorResponse.error.message
          setTimeout(() => { this.message=''}, 2000);
      }
    );
  }

}
