import { EventEmitter, Injectable } from "@angular/core";
import { Ingredient } from "../shared/ingredient.model";
import { ShoppingListService } from "../shopping-list/shopping-list.service";
import { Recipe } from "./recipe.model";

@Injectable()
export class RecipeService {
    recipeSelected = new EventEmitter<Recipe>();
    recipesChanged = new EventEmitter<Recipe[]>();

    private recipes: Recipe[] = [
        new Recipe('Chicken Biryani', 'This is simply biryani', 'https://media.istockphoto.com/photos/chicken-biryani-directly-above-photo-picture-id1169141170?k=20&m=1169141170&s=612x612&w=0&h=EpCF3lQF2GBRaVApNELuE5xFQfv8fyQ_wWC52hmyxeo=',[
            new Ingredient('Chicken', 1),
            new Ingredient('Rice', 20)
        ]),
        new Recipe('Chicken noodles', 'This is simply noodles', 'https://media.istockphoto.com/photos/spaghetti-with-tomato-sauce-shot-on-rustic-wooden-table-picture-id1166258781?k=20&m=1166258781&s=612x612&w=0&h=vS53c6WSCkbW80i4KHqa3bKbtg52SLrHFjpjjpi4hI0=',[
            new Ingredient('Chicken', 1),
            new Ingredient('Noodles', 20)
        ]),
        new Recipe('Cheesy Burger', 'This is simply Burger', 'https://embed.widencdn.net/img/beef/1akcqwmdqs/1120x840px/classic-beef-cheeseburgers-horizontal.tif?keep=c&u=7fueml',[
            new Ingredient('Chicken', 2),
            new Ingredient('Cheese', 2)
        ]),
        new Recipe('Pizza', 'This is simply pizza', 'https://www.dominos.co.in/files/items/_1346164951.jpg',[
            new Ingredient('vegitables', 4),
            new Ingredient('Cheese', 2)
        ])

    ];

    constructor(private slService: ShoppingListService) {}
    
    getRecipes() {
        return this.recipes.slice();
    }

    getRecipe(index: number) {
        return this.recipes[index];
    }
    
    addIngredientsToList(ingredients: Ingredient[]) {
        this.slService.addIngredients(ingredients);
    }

    addRecipe(recipe: Recipe) {
        this.recipes.push(recipe);
        this.recipesChanged.emit(this.recipes.slice());
    }

    updateRecipe(index: number, newRecipe: Recipe) {
        this.recipes[index] = newRecipe;
        this.recipesChanged.emit(this.recipes.slice());
    }
    
    deleteRecipe(index: number) {
        this.recipes.splice(index, 1);
        this.recipesChanged.emit(this.recipes.slice());
    }
}